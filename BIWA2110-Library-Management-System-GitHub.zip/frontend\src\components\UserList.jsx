import React, { useState } from 'react';
import { Users, Edit2, Trash2, Shield, UserCheck, Search } from 'lucide-react';

export default function UserList({
    users = [],
    loading = false,
    onEditUser,
    onDeleteUser,
    currentUserId
}) {
    const [searchTerm, setSearchTerm] = useState('');
    const [roleFilter, setRoleFilter] = useState('All');

    const filteredUsers = users.filter((u) => {
        const matchesSearch =
            !searchTerm.trim() ||
            u.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            u.membership_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            u.email?.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesRole = roleFilter === 'All' || u.role === roleFilter;
        return matchesSearch && matchesRole;
    });

    const getRoleBadge = (role) => {
        switch (role) {
            case 'Admin':
                return <span className="badge badge-admin"><Shield size={12} /> Admin</span>;
            case 'Librarian':
                return <span className="badge badge-librarian"><UserCheck size={12} /> Librarian</span>;
            default:
                return <span className="badge badge-member">Member</span>;
        }
    };

    if (loading) {
        return (
            <div className="card-container">
                <div className="loading-state">
                    <div className="spinner"></div>
                    <p>Loading registered users...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="card-container">
            <div className="card-header-flex">
                <div className="card-title-group">
                    <h3 className="section-title">
                        <Users size={20} className="inline-icon" /> Registered Users & Members
                    </h3>
                    <span className="count-pill">{filteredUsers.length} accounts</span>
                </div>

                <div className="filter-controls">
                    <div className="search-bar">
                        <Search size={18} className="search-icon" />
                        <input
                            type="text"
                            placeholder="Search name, ID, or email..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="input-search"
                        />
                    </div>

                    <div className="genre-filter">
                        <select
                            value={roleFilter}
                            onChange={(e) => setRoleFilter(e.target.value)}
                            className="select-filter"
                        >
                            <option value="All">All Roles</option>
                            <option value="Admin">Admins</option>
                            <option value="Librarian">Librarians</option>
                            <option value="Member">Members</option>
                        </select>
                    </div>
                </div>
            </div>

            {filteredUsers.length === 0 ? (
                <div className="empty-state">
                    <Users size={48} className="empty-icon" />
                    <h3>No Users Found</h3>
                    <p>No user accounts matched the search criteria.</p>
                </div>
            ) : (
                <div className="table-responsive">
                    <table className="custom-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Membership ID</th>
                                <th>Role</th>
                                <th>Email</th>
                                <th className="text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsers.map((u, idx) => {
                                const isSelf = currentUserId && String(u.id) === String(currentUserId);
                                return (
                                    <tr key={u.id}>
                                        <td className="cell-id">{idx + 1}</td>
                                        <td>
                                            <div className="user-cell-flex">
                                                <div className="user-avatar-sm">
                                                    {u.name?.charAt(0).toUpperCase()}
                                                </div>
                                                <span className="font-semibold">{u.name}</span>
                                                {isSelf && <span className="self-tag">(You)</span>}
                                            </div>
                                        </td>
                                        <td>
                                            <code className="isbn-tag">{u.membership_id}</code>
                                        </td>
                                        <td>
                                            {getRoleBadge(u.role)}
                                        </td>
                                        <td className="text-muted">{u.email}</td>
                                        <td className="text-right actions-cell">
                                            <button
                                                onClick={() => onEditUser(u)}
                                                className="btn-action btn-action-edit"
                                                title="Edit User"
                                            >
                                                <Edit2 size={14} /> Update
                                            </button>
                                            <button
                                                onClick={() => onDeleteUser(u)}
                                                className="btn-action btn-action-delete"
                                                title="Delete User"
                                            >
                                                <Trash2 size={14} /> Delete
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
