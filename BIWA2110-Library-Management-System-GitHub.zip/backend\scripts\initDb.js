const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function runInit() {
    console.log('[Init-DB] Reading backend/database.sql ...');
    const sqlScript = fs.readFileSync(path.join(__dirname, '..', 'database.sql'), 'utf-8');

    const config = {
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        port: parseInt(process.env.DB_PORT, 10) || 3306,
        multipleStatements: true
    };

    try {
        console.log(`[Init-DB] Connecting to MySQL at ${config.host}:${config.port}...`);
        const connection = await mysql.createConnection(config);
        console.log('[Init-DB] Executing SQL schema and seed scripts...');
        await connection.query(sqlScript);
        console.log('[Init-DB] Database "library_db" initialized and seeded successfully in MySQL!');
        await connection.end();
        process.exit(0);
    } catch (err) {
        console.error('[Init-DB] Failed to run MySQL script:', err.message);
        console.log('[Init-DB] Note: If MySQL is not running yet, you can start MySQL in XAMPP and run this again, or start the server with "npm start" which uses the embedded resilient database automatically.');
        process.exit(1);
    }
}

runInit();
