import React, { useState, useEffect } from 'react';
import { ArrowDownCircle, ArrowUpCircle, AlertCircle, CheckCircle, PackagePlus, BookMinus } from 'lucide-react';

export default function TransactionForm({
    books = [],
    users = [],
    onTransactionComplete,
    submitting = false,
    preselectedBookId = null
}) {
    const [formData, setFormData] = useState({
        book_id: preselectedBookId || '',
        transaction_type: 'BORROW_STOCK', // 'ADD_STOCK' or 'BORROW_STOCK'
        quantity: 1,
        user_id: '',
        notes: ''
    });

    const [errors, setErrors] = useState({});

    useEffect(() => {
        if (preselectedBookId) {
            setFormData((prev) => ({ ...prev, book_id: preselectedBookId }));
        } else if (books.length > 0 && !formData.book_id) {
            setFormData((prev) => ({ ...prev, book_id: books[0].id }));
        }
    }, [preselectedBookId, books]);

    // Selected book details
    const selectedBook = books.find((b) => String(b.id) === String(formData.book_id));
    const currentStock = selectedBook ? parseInt(selectedBook.quantity, 10) : 0;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        if (errors[name]) {
            setErrors((prev) => ({ ...prev, [name]: null }));
        }
    };

    const handleTypeSelect = (type) => {
        setFormData((prev) => ({ ...prev, transaction_type: type }));
        setErrors({});
    };

    const validate = () => {
        const newErrors = {};

        if (!formData.book_id) {
            newErrors.book_id = 'Please select a book';
        }

        const qty = parseInt(formData.quantity, 10);
        if (isNaN(qty) || qty <= 0) {
            newErrors.quantity = 'Quantity must be at least 1';
        } else if (formData.transaction_type === 'BORROW_STOCK' && selectedBook) {
            if (qty > currentStock) {
                newErrors.quantity = `Cannot borrow ${qty} copies. Only ${currentStock} copy/copies available!`;
            }
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        const success = await onTransactionComplete({
            book_id: parseInt(formData.book_id, 10),
            transaction_type: formData.transaction_type,
            quantity: parseInt(formData.quantity, 10),
            user_id: formData.user_id ? parseInt(formData.user_id, 10) : null,
            notes: formData.notes.trim()
        });

        if (success) {
            setFormData((prev) => ({
                ...prev,
                quantity: 1,
                notes: ''
            }));
            setErrors({});
        }
    };

    return (
        <div className="card-container form-card">
            <div className="form-card-header">
                <div className={`header-icon-box ${formData.transaction_type === 'ADD_STOCK' ? 'box-green' : 'box-blue'}`}>
                    {formData.transaction_type === 'ADD_STOCK' ? (
                        <PackagePlus size={20} />
                    ) : (
                        <BookMinus size={20} />
                    )}
                </div>
                <div>
                    <h3 className="section-title">Availability & Stock Transaction</h3>
                    <p className="section-subtitle">
                        Record book arrivals (add stock) or student borrowing (deduct stock).
                    </p>
                </div>
            </div>

            {/* Transaction Type Segmented Control */}
            <div className="tx-type-selector">
                <button
                    type="button"
                    className={`tx-type-btn ${formData.transaction_type === 'BORROW_STOCK' ? 'active-borrow' : ''}`}
                    onClick={() => handleTypeSelect('BORROW_STOCK')}
                >
                    <ArrowDownCircle size={18} />
                    <span>Deduct Stock (Borrow Book)</span>
                </button>

                <button
                    type="button"
                    className={`tx-type-btn ${formData.transaction_type === 'ADD_STOCK' ? 'active-add' : ''}`}
                    onClick={() => handleTypeSelect('ADD_STOCK')}
                >
                    <ArrowUpCircle size={18} />
                    <span>Add Stock (New Arrival / Return)</span>
                </button>
            </div>

            <form onSubmit={handleSubmit} noValidate className="form-grid">
                {/* Book Selection */}
                <div className="form-group col-span-2">
                    <label htmlFor="book_id" className="form-label">
                        Select Book <span className="required-star">*</span>
                    </label>
                    <select
                        id="book_id"
                        name="book_id"
                        value={formData.book_id}
                        onChange={handleChange}
                        className={`form-select ${errors.book_id ? 'input-error' : ''}`}
                        disabled={submitting}
                    >
                        <option value="">-- Choose a book from inventory --</option>
                        {books.map((b) => (
                            <option key={b.id} value={b.id}>
                                {b.title} — Stock: {b.quantity} (ISBN: {b.isbn})
                            </option>
                        ))}
                    </select>
                    {errors.book_id && (
                        <span className="error-message"><AlertCircle size={13} /> {errors.book_id}</span>
                    )}

                    {/* Quick Stock Status Box */}
                    {selectedBook && (
                        <div className={`stock-preview-box ${currentStock < 2 ? 'preview-low' : 'preview-normal'}`}>
                            <div className="preview-label">
                                <strong>Selected:</strong> {selectedBook.title}
                            </div>
                            <div className="preview-stock">
                                Current Stock: <strong>{currentStock} copies</strong>
                                {currentStock === 0 && <span className="stock-alert-tag">OUT OF STOCK</span>}
                                {currentStock === 1 && <span className="stock-alert-tag">LOW STOCK</span>}
                            </div>
                        </div>
                    )}
                </div>

                {/* Quantity */}
                <div className="form-group">
                    <label htmlFor="quantity" className="form-label">
                        Quantity to {formData.transaction_type === 'ADD_STOCK' ? 'Add' : 'Borrow'}{' '}
                        <span className="required-star">*</span>
                    </label>
                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        min="1"
                        max={formData.transaction_type === 'BORROW_STOCK' && selectedBook ? currentStock : 9999}
                        value={formData.quantity}
                        onChange={handleChange}
                        className={`form-input ${errors.quantity ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.quantity && (
                        <span className="error-message"><AlertCircle size={13} /> {errors.quantity}</span>
                    )}
                </div>

                {/* Member / User Selection */}
                <div className="form-group">
                    <label htmlFor="user_id" className="form-label">
                        Member / Responsible User
                    </label>
                    <select
                        id="user_id"
                        name="user_id"
                        value={formData.user_id}
                        onChange={handleChange}
                        className="form-select"
                        disabled={submitting}
                    >
                        <option value="">-- Walk-in / General Library Record --</option>
                        {users.map((u) => (
                            <option key={u.id} value={u.id}>
                                {u.name} ({u.membership_id} - {u.role})
                            </option>
                        ))}
                    </select>
                </div>

                {/* Transaction Notes */}
                <div className="form-group col-span-2">
                    <label htmlFor="notes" className="form-label">
                        Transaction Notes / Purpose
                    </label>
                    <input
                        type="text"
                        id="notes"
                        name="notes"
                        value={formData.notes}
                        onChange={handleChange}
                        placeholder="e.g. Student assignment loan, faculty delivery, new term purchase..."
                        className="form-input"
                        disabled={submitting}
                    />
                </div>

                {/* Submit Action */}
                <div className="form-actions col-span-2">
                    <button
                        type="submit"
                        className={`btn-primary w-full ${formData.transaction_type === 'ADD_STOCK' ? 'btn-success' : 'btn-indigo'}`}
                        disabled={submitting || (formData.transaction_type === 'BORROW_STOCK' && currentStock === 0)}
                    >
                        {submitting ? (
                            <>
                                <span className="spinner-sm"></span>
                                <span>Recording Transaction...</span>
                            </>
                        ) : formData.transaction_type === 'ADD_STOCK' ? (
                            <>
                                <ArrowUpCircle size={18} />
                                <span>Add {formData.quantity} Copies to Stock</span>
                            </>
                        ) : (
                            <>
                                <ArrowDownCircle size={18} />
                                <span>Borrow {formData.quantity} Copies (Deduct Stock)</span>
                            </>
                        )}
                    </button>
                </div>
            </form>
        </div>
    );
}
