# Web Application Development - BIWA2110 Labtest (20%)
## Library Management & Availability System

**Institution:** Limkokwing University of Creative Technology  
**Department:** Faculty of Information Communication Technology  
**Courses:** Degree in Business Information Technology / Degree in Information Technology  
**Semester:** 1 | **Commence/Deadline:** Week 12  
**Total Marks:** 80 Marks (Weight: 20%)

---

## 📖 Project Overview

This project is a full-stack Web Application designed for university libraries to manage book inventories, track live stock availability, log borrowing/restocking transactions, and handle member authentication and account administration.

It is structured strictly in accordance with the **BIWA2110 Labtest Specification**:
- **`frontend/`**: Single-Page Application (SPA) built using React (JSX), React Router, React Hooks (`useState`, `useEffect`, `useContext`, `useMemo`, `useCallback`), controlled form validation, and responsive styling.
- **`backend/`**: RESTful API built with Node.js and Express.js with full CRUD routing (`/books`, `/transactions`, `/users`), `cors()`, `express.json()`, and relational database integration.
- **Database**: Full support for MySQL (with `database.sql` script for XAMPP / phpMyAdmin) and PostgreSQL (`schema.sql`), with an automatic embedded SQLite layer for zero-config evaluation.

---

## 🎯 Features Checklist vs. Marking Criteria

| Requirement | Implementation Details | Status |
| :--- | :--- | :---: |
| **1. Book Management** | | |
| • Add new books | Title, Author, Genre, ISBN, Initial Quantity with validation | ✅ Complete |
| • Update existing books | Modal form allowing updates to title, author, genre, ISBN, quantity | ✅ Complete |
| • Delete books | Secure deletion of books no longer available | ✅ Complete |
| **2. Availability Management** | | |
| • Track quantity in stock | Real-time stock counters across shelves, table rows, and cards | ✅ Complete |
| • Add stock | Restocking transaction increases inventory count with audit note | ✅ Complete |
| • Deduct stock (Borrow) | Prevents borrowing beyond available quantity; deducts stock | ✅ Complete |
| • Transaction History Log | Filterable, searchable log recording every stock change & loan | ✅ Complete |
| **3. User Management** | | |
| • User login form | Email/Membership ID + password authentication | ✅ Complete |
| • Add new users | Full Name, Membership ID, Role (Admin/Librarian/Member), Email, Password | ✅ Complete |
| • Update user details | Edit user accounts and role assignments | ✅ Complete |
| • Delete users | Remove members/users (with self-delete protection) | ✅ Complete |
| **4. UI Design & Navigation** | | |
| • Dashboard | KPI stats, availability table/cards, low stock highlight (< 2 copies) | ✅ Complete |
| • Book Management Page | Controlled form for adding books + editable catalog list | ✅ Complete |
| • Transactions Page | Dual forms/buttons to add/deduct stock + transaction history log | ✅ Complete |
| • User Management Page | Login form for authentication + Admin view to add/update/delete users | ✅ Complete |
| • Responsive Design | Desktop, tablet, and mobile navigation with hamburger toggle | ✅ Complete |

---

## 📂 Project Architecture

```text
library-management-system/
├── backend/
│   ├── config/
│   │   └── db.js                 # Database pool & resilient connection layer
│   ├── routes/
│   │   ├── books.js              # CRUD routes for /books
│   │   ├── transactions.js       # CRUD & stock management for /transactions
│   │   └── users.js             # Authentication & CRUD for /users
│   ├── scripts/
│   │   └── initDb.js             # Automated database initialization script
│   ├── database.sql              # MySQL schema & seed data (for XAMPP/phpMyAdmin)
│   ├── schema.sql                # PostgreSQL schema & seed data
│   ├── .env                      # Database configuration
│   ├── server.js                 # Express server & middleware setup
│   └── package.json
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx            # Responsive header with user badge & route links
│   │   │   ├── DashboardStats.jsx    # KPI metrics (Total books, volume, low stock)
│   │   │   ├── BookList.jsx          # Table & card views with low stock highlights
│   │   │   ├── AddBookForm.jsx       # Controlled book addition form with validation
│   │   │   ├── EditBookModal.jsx     # Update book modal dialog
│   │   │   ├── TransactionForm.jsx   # Add/deduct stock form with real-time stock cap
│   │   │   ├── TransactionHistory.jsx# Searchable audit log of borrowings & restocks
│   │   │   ├── LoginForm.jsx         # Controlled login form with demo credentials
│   │   │   ├── UserForm.jsx          # Register user form (Name, ID, Role, Email)
│   │   │   ├── UserList.jsx          # Admin view table with Update/Delete actions
│   │   │   └── EditUserModal.jsx     # Update user details modal
│   │   ├── context/
│   │   │   ├── AuthContext.jsx       # Session state management
│   │   │   └── NotificationContext.jsx# Toast notification system
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx         # Overview, KPI cards, low stock banner
│   │   │   ├── BookManagement.jsx    # Add book form + editable book catalog
│   │   │   ├── Transactions.jsx      # Stock adjuster + transaction history log
│   │   │   ├── UserManagement.jsx    # User login + Admin view for user management
│   │   │   └── LoginPage.jsx         # Standalone login route
│   │   ├── services/
│   │   │   └── api.js                # Reusable Fetch API client
│   │   ├── App.jsx                   # React Router route definitions
│   │   ├── main.jsx                  # Application entry point
│   │   └── index.css                 # Clean, responsive styling & color scheme
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
│
├── start-app.bat                     # Windows 1-click batch launcher
├── .gitignore
├── package.json
└── README.md
```

---

## 🚀 Quick Start Guide

### Prerequisites
- **Node.js**: v16+ (v20+ recommended)
- **Database (Optional)**: XAMPP MySQL (port 3306) or MySQL Server.  
  *(Note: If MySQL is not running, the application automatically uses an embedded SQLite database with identical schema and seed data so it runs out of the box with zero setup).*

### Option 1: One-Click Launch (Windows)
Double-click `start-app.bat` in the root folder. It will automatically start both the Express backend on port 5000 and the React frontend on port 3000.

---

### Option 2: Manual Terminal Startup

#### 1. Start Backend Server
```bash
cd backend
npm install
npm start
```
The server will run on `http://localhost:5000`.

#### 2. Start Frontend App
Open a second terminal window:
```bash
cd frontend
npm install
npm run dev
```
The React application will run on `http://localhost:3000`.

---

## 🗄️ Setting Up MySQL with XAMPP (Recommended for Submission)

1. Open **XAMPP Control Panel** and click **Start** next to **MySQL** (and Apache).
2. Open your browser and navigate to `http://localhost/phpmyadmin`.
3. Click on the **SQL** tab.
4. Copy and paste the contents of `backend/database.sql` into the SQL window and click **Go**.
5. The `library_db` database and all tables (`users`, `books`, `transactions`) will be created with pre-populated demo data.
6. Verify database credentials in `backend/.env`:
   ```env
   PORT=5000
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=
   DB_NAME=library_db
   DB_PORT=3306
   ```

---

## 🔑 Demo Login Accounts

For testing authentication on the **User Management** page or **Sign In** button:

| Role | Email / Membership ID | Password | Access Privileges |
| :--- | :--- | :--- | :--- |
| **System Administrator** | `admin@limkokwing.ac.ls` *(or `ADM-001`)* | `admin123` | Full administrative control |
| **Student Member** | `john.doe@student.limkokwing.ac.ls` *(or `MEM-101`)* | `password123` | Standard borrower |
| **Faculty Librarian** | `thabo.mokoena@limkokwing.ac.ls` *(or `LIB-002`)* | `lib123` | Library staff |

*(Quick-fill buttons are also provided on the login form for 1-click credential filling).*

---

## 🌐 RESTful API Endpoints Reference

### Books (`/api/books` or `/books`)
- `GET /api/books` - Retrieve all books (supports query params `?search=term&genre=genreName`)
- `GET /api/books/:id` - Retrieve book by ID
- `POST /api/books` - Add a new book (Body: `title`, `author`, `genre`, `isbn`, `quantity`)
- `PUT /api/books/:id` - Update book details
- `DELETE /api/books/:id` - Remove book from catalog

### Transactions (`/api/transactions` or `/transactions`)
- `GET /api/transactions` - Fetch transaction audit log with joined book & member info
- `GET /api/transactions/stats` - Fetch aggregate metrics for dashboard
- `POST /api/transactions` - Record transaction (`book_id`, `transaction_type` ['ADD_STOCK', 'BORROW_STOCK'], `quantity`, `user_id`, `notes`)

### Users (`/api/users` or `/users`)
- `POST /api/users/login` - Authenticate user (`identifier`, `password`)
- `GET /api/users` - List all users
- `GET /api/users/:id` - Retrieve single user details
- `POST /api/users` - Register new user (`name`, `membership_id`, `role`, `email`, `password`)
- `PUT /api/users/:id` - Update user details
- `DELETE /api/users/:id` - Remove user account

---

## 📤 GitHub Submission Instructions

As specified in the assignment brief:
> **Submit a link to your GitHub project containing both:**
> - `frontend/` (React app)
> - `backend/` (Express + DB)

To push this project to your GitHub repository:
```bash
# 1. Initialize git repository in the project root
git init

# 2. Add all files
git add .

# 3. Create initial commit
git commit -m "feat: complete BIWA2110 library management web application labtest"

# 4. Link to your GitHub repository (replace with your repo URL)
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git

# 5. Push to GitHub
git push -u origin main
```
Copy your repository link (e.g., `https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME`) and submit it on your student portal / Google Classroom!
