const defaultBooks = [
    {
        title: "Introduction to Algorithms",
        author: "Thomas H. Cormen",
        genre: "Computer Science",
        isbn: "978-0262033848",
        quantity: 5
    },
    {
        title: "Clean Code",
        author: "Robert C. Martin",
        genre: "Information Technology",
        isbn: "978-0132350884",
        quantity: 1
    },
    {
        title: "Management Information Systems",
        author: "Kenneth C. Laudon",
        genre: "Business Management",
        isbn: "978-0135191798",
        quantity: 4
    },
    {
        title: "Lithoko tsa marena a Basotho",
        author: "Zakea D. Mangoaela",
        genre: "Praise Poetry or Oral Literature Anthologies",
        isbn: "978-0596517748",
        quantity: 0
    }
];

const defaultUsers = [
    {
        name: "Tlotliso Mabaleha",
        memberId: "LIB-001",
        role: "Librarian",
        password: "admin123",
        date: "2026-08-01"
    },
    {
        name: "Tanki Seisa",
        memberId: "ADM-002",
        role: "Admin",
        password: "admin123",
        date: "2026-08-05"
    },
    {
        name: "Tumelo Mabuti",
        memberId: "STU-101",
        role: "Member",
        password: "student123",
        date: "2026-08-15"
    }
];

const defaultTransactions = [
    {
        date: "2026-08-28 09:30 AM",
        bookTitle: "Clean Code",
        type: "Borrow",
        quantity: 1,
        user: "Tumelo Mabuti (STU-101)",
        notes: "Assignment 1 reference"
    },
    {
        date: "2026-08-25 02:15 PM",
        bookTitle: "Introduction to Algorithms",
        type: "Add Stock",
        quantity: 3,
        user: "Tlotliso Mabaleha (LIB-001)",
        notes: "New stock arrival from department"
    }
];

function getBooksFromStorage() {
    const data = localStorage.getItem("library_books");
    if (!data) {
        localStorage.setItem("library_books", JSON.stringify(defaultBooks));
        return defaultBooks;
    }
    const parsed = JSON.parse(data);
    if (parsed.length > 3 && parsed[3].title === "JavaScript: The Good Parts") {
        parsed[3] = defaultBooks[3];
        localStorage.setItem("library_books", JSON.stringify(parsed));
    }
    return parsed;
}

function saveBooksToStorage(books) {
    localStorage.setItem("library_books", JSON.stringify(books));
}

function getUsersFromStorage() {
    const data = localStorage.getItem("library_users");
    if (!data) {
        localStorage.setItem("library_users", JSON.stringify(defaultUsers));
        return defaultUsers;
    }
    const parsed = JSON.parse(data);
    if (parsed.length > 0 && (parsed[0].name === "Mpho Takalimane" || parsed[0].name === "Tlotliso Moscow Mabaleha")) {
        localStorage.setItem("library_users", JSON.stringify(defaultUsers));
        return defaultUsers;
    }
    return parsed;
}

function saveUsersToStorage(users) {
    localStorage.setItem("library_users", JSON.stringify(users));
}

function getTransactionsFromStorage() {
    const data = localStorage.getItem("library_transactions");
    if (!data) {
        localStorage.setItem("library_transactions", JSON.stringify(defaultTransactions));
        return defaultTransactions;
    }
    const parsed = JSON.parse(data);
    if (parsed.length > 0 && parsed[0].user && (parsed[0].user.includes("Alice Khaketla") || parsed[0].user.includes("Mpho Takalimane"))) {
        localStorage.setItem("library_transactions", JSON.stringify(defaultTransactions));
        return defaultTransactions;
    }
    return parsed;
}

function saveTransactionsToStorage(transactions) {
    localStorage.setItem("library_transactions", JSON.stringify(transactions));
}

function getCurrentUserSession() {
    const data = localStorage.getItem("library_current_user");
    return data ? JSON.parse(data) : null;
}

function setCurrentUserSession(user) {
    if (user) {
        localStorage.setItem("library_current_user", JSON.stringify(user));
    } else {
        localStorage.removeItem("library_current_user");
    }
}

function showAlert(message, type = "info") {
    const alertBox = document.getElementById("alert-box");
    alertBox.className = `alert-message alert-${type}`;
    alertBox.textContent = message;
    alertBox.style.display = "block";
    window.scrollTo({ top: 0, behavior: "smooth" });

    setTimeout(() => {
        alertBox.style.display = "none";
    }, 4000);
}

function initNavigation() {
    const navButtons = document.querySelectorAll(".nav-btn");
    const sections = document.querySelectorAll(".view-section");

    navButtons.forEach(button => {
        button.addEventListener("click", () => {
            navButtons.forEach(btn => btn.classList.remove("active"));
            sections.forEach(sec => sec.classList.remove("active"));
            button.classList.add("active");
            const targetId = button.getAttribute("data-target");
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.add("active");
            }
            renderAllViews();
        });
    });
}

function renderDashboard() {
    const books = getBooksFromStorage();
    const users = getUsersFromStorage();

    const totalBooks = books.length;
    let totalCopies = 0;
    let lowStockCount = 0;

    books.forEach(book => {
        const qty = parseInt(book.quantity, 10) || 0;
        totalCopies += qty;
        if (qty < 2) {
            lowStockCount++;
        }
    });

    document.getElementById("stat-total-books").textContent = totalBooks;
    document.getElementById("stat-total-stock").textContent = totalCopies;
    document.getElementById("stat-low-stock").textContent = lowStockCount;
    document.getElementById("stat-total-users").textContent = users.length;

    const tbody = document.getElementById("dashboard-books-tbody");
    tbody.innerHTML = "";

    const searchTerm = (document.getElementById("dashboard-search-input").value || "").toLowerCase().trim();

    const filteredBooks = books.filter(book => {
        return book.title.toLowerCase().includes(searchTerm) ||
               book.author.toLowerCase().includes(searchTerm) ||
               book.genre.toLowerCase().includes(searchTerm) ||
               book.isbn.toLowerCase().includes(searchTerm);
    });

    if (filteredBooks.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: #888;">No books found.</td></tr>`;
        return;
    }

    filteredBooks.forEach(book => {
        const row = document.createElement("tr");
        const qty = parseInt(book.quantity, 10) || 0;

        if (qty < 2) {
            row.classList.add("low-stock-row");
        }

        let statusBadge = "";
        if (qty === 0) {
            statusBadge = '<span class="badge badge-danger">Out of Stock</span>';
        } else if (qty < 2) {
            statusBadge = '<span class="badge badge-warning">Low Stock (&lt; 2)</span>';
        } else {
            statusBadge = '<span class="badge badge-success">In Stock</span>';
        }

        row.innerHTML = `
            <td><code>${escapeHtml(book.isbn)}</code></td>
            <td><strong>${escapeHtml(book.title)}</strong></td>
            <td>${escapeHtml(book.author)}</td>
            <td><span class="badge badge-info">${escapeHtml(book.genre)}</span></td>
            <td><strong>${qty}</strong></td>
            <td>${statusBadge}</td>
        `;

        tbody.appendChild(row);
    });
}

function renderBooksTable() {
    const books = getBooksFromStorage();
    const tbody = document.getElementById("books-tbody");
    const countBadge = document.getElementById("book-count-badge");

    countBadge.textContent = `${books.length} Books`;
    tbody.innerHTML = "";

    if (books.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: #888;">No books available in the library database.</td></tr>`;
        return;
    }

    books.forEach((book, index) => {
        const row = document.createElement("tr");
        const qty = parseInt(book.quantity, 10) || 0;

        if (qty < 2) {
            row.classList.add("low-stock-row");
        }

        row.innerHTML = `
            <td>
                <strong>${escapeHtml(book.title)}</strong><br>
                <small class="text-muted">by ${escapeHtml(book.author)}</small>
            </td>
            <td><span class="badge badge-info">${escapeHtml(book.genre)}</span></td>
            <td><code>${escapeHtml(book.isbn)}</code></td>
            <td>
                <strong>${qty}</strong>
                ${qty < 2 ? ' <span class="badge badge-danger">Low</span>' : ''}
            </td>
            <td>
                <div class="action-btn-group">
                    <button class="btn btn-sm btn-primary" onclick="editBook(${index})">Update</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteBook(${index})">Delete</button>
                </div>
            </td>
        `;

        tbody.appendChild(row);
    });
}

function initBookForm() {
    const bookForm = document.getElementById("book-form");
    const cancelBtn = document.getElementById("book-cancel-edit-btn");

    bookForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const title = document.getElementById("book-title").value.trim();
        const author = document.getElementById("book-author").value.trim();
        const genre = document.getElementById("book-genre").value;
        const isbn = document.getElementById("book-isbn").value.trim();
        const quantity = parseInt(document.getElementById("book-quantity").value, 10);
        const editIndex = parseInt(document.getElementById("book-edit-index").value, 10);

        if (!title || !author || !genre || !isbn || isNaN(quantity) || quantity < 0) {
            showAlert("Please fill in all fields with valid information.", "danger");
            return;
        }

        const books = getBooksFromStorage();
        const duplicate = books.find((b, idx) => b.isbn.toLowerCase() === isbn.toLowerCase() && idx !== editIndex);
        if (duplicate) {
            showAlert(`A book with ISBN "${isbn}" already exists (${duplicate.title}).`, "danger");
            return;
        }

        if (editIndex >= 0 && editIndex < books.length) {
            books[editIndex] = { title, author, genre, isbn, quantity };
            saveBooksToStorage(books);
            showAlert(`Book "${title}" has been updated successfully!`, "success");
            resetBookForm();
        } else {
            books.push({ title, author, genre, isbn, quantity });
            saveBooksToStorage(books);
            showAlert(`Book "${title}" added successfully with ${quantity} copies!`, "success");
            resetBookForm();
        }

        renderAllViews();
    });

    cancelBtn.addEventListener("click", resetBookForm);
}

function editBook(index) {
    const books = getBooksFromStorage();
    const book = books[index];
    if (!book) return;

    document.querySelector('.nav-btn[data-target="books-section"]').click();
    document.getElementById("book-edit-index").value = index;
    document.getElementById("book-title").value = book.title;
    document.getElementById("book-author").value = book.author;
    document.getElementById("book-genre").value = book.genre;
    document.getElementById("book-isbn").value = book.isbn;
    document.getElementById("book-quantity").value = book.quantity;
    document.getElementById("book-form-heading").textContent = "Update Book Details";
    document.getElementById("book-save-btn").textContent = "Update Book";
    document.getElementById("book-cancel-edit-btn").style.display = "inline-block";
    document.getElementById("book-form").scrollIntoView({ behavior: "smooth" });
}

function deleteBook(index) {
    const books = getBooksFromStorage();
    const book = books[index];
    if (!book) return;

    const confirmDelete = confirm(`Are you sure you want to delete "${book.title}" (ISBN: ${book.isbn}) from the library?`);
    if (confirmDelete) {
        books.splice(index, 1);
        saveBooksToStorage(books);
        showAlert(`Book "${book.title}" was deleted.`, "info");
        resetBookForm();
        renderAllViews();
    }
}

function resetBookForm() {
    document.getElementById("book-form").reset();
    document.getElementById("book-edit-index").value = "-1";
    document.getElementById("book-form-heading").textContent = "Add New Book";
    document.getElementById("book-save-btn").textContent = "Add Book";
    document.getElementById("book-cancel-edit-btn").style.display = "none";
}

function populateTransactionDropdowns() {
    const books = getBooksFromStorage();
    const bookSelect = document.getElementById("trans-book-select");

    bookSelect.innerHTML = '<option value="">-- Choose a Book --</option>';

    books.forEach(book => {
        const option = document.createElement("option");
        option.value = book.isbn;
        option.textContent = `${book.title} (Stock: ${book.quantity} copies)`;
        bookSelect.appendChild(option);
    });

    const quickList = document.getElementById("quick-stock-list");
    quickList.innerHTML = "";

    if (books.length === 0) {
        quickList.innerHTML = '<div style="padding: 15px; color: #888; text-align: center;">No books in inventory.</div>';
        return;
    }

    books.forEach(book => {
        const item = document.createElement("div");
        item.className = "quick-stock-item";

        let badgeClass = "badge-success";
        if (book.quantity === 0) badgeClass = "badge-danger";
        else if (book.quantity < 2) badgeClass = "badge-warning";

        item.innerHTML = `
            <div>
                <div class="quick-stock-title">${escapeHtml(book.title)}</div>
                <div class="quick-stock-sub">ISBN: ${escapeHtml(book.isbn)}</div>
            </div>
            <span class="badge ${badgeClass}">${book.quantity} in stock</span>
        `;
        quickList.appendChild(item);
    });
}

function renderTransactionsTable() {
    const transactions = getTransactionsFromStorage();
    const tbody = document.getElementById("transactions-tbody");
    tbody.innerHTML = "";

    if (transactions.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: #888;">No transactions recorded yet.</td></tr>`;
        return;
    }

    const reversed = [...transactions].reverse();

    reversed.forEach(t => {
        const row = document.createElement("tr");

        let typeBadge = '<span class="badge badge-info">' + escapeHtml(t.type) + '</span>';
        if (t.type === "Borrow") {
            typeBadge = '<span class="badge badge-warning">Borrow (- stock)</span>';
        } else if (t.type === "Add Stock" || t.type === "Return") {
            typeBadge = '<span class="badge badge-success">' + escapeHtml(t.type) + ' (+ stock)</span>';
        }

        row.innerHTML = `
            <td><small>${escapeHtml(t.date)}</small></td>
            <td><strong>${escapeHtml(t.bookTitle)}</strong></td>
            <td>${typeBadge}</td>
            <td><strong>${t.quantity}</strong></td>
            <td>${escapeHtml(t.user)}</td>
            <td><small>${escapeHtml(t.notes || "-")}</small></td>
        `;
        tbody.appendChild(row);
    });
}

function initTransactionForm() {
    const transForm = document.getElementById("transaction-form");
    const clearBtn = document.getElementById("clear-transactions-btn");

    transForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const isbn = document.getElementById("trans-book-select").value;
        const type = document.getElementById("trans-type").value;
        const quantity = parseInt(document.getElementById("trans-quantity").value, 10);
        const userName = document.getElementById("trans-user-name").value.trim();
        const notes = document.getElementById("trans-notes").value.trim();

        if (!isbn) {
            showAlert("Please select a book from the list.", "danger");
            return;
        }

        if (isNaN(quantity) || quantity <= 0) {
            showAlert("Quantity must be at least 1.", "danger");
            return;
        }

        const books = getBooksFromStorage();
        const bookIndex = books.findIndex(b => b.isbn === isbn);

        if (bookIndex === -1) {
            showAlert("Selected book could not be found.", "danger");
            return;
        }

        const targetBook = books[bookIndex];

        if (type === "Borrow") {
            if (targetBook.quantity < quantity) {
                showAlert(`Cannot borrow ${quantity} copies. Only ${targetBook.quantity} copies are currently available!`, "danger");
                return;
            }
            targetBook.quantity -= quantity;
        } else {
            targetBook.quantity += quantity;
        }

        saveBooksToStorage(books);
        const now = new Date();
        const dateStr = now.toLocaleDateString() + " " + now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const transactions = getTransactionsFromStorage();
        transactions.push({
            date: dateStr,
            bookTitle: targetBook.title,
            type: type,
            quantity: quantity,
            user: userName,
            notes: notes
        });
        saveTransactionsToStorage(transactions);

        showAlert(`Transaction successful! ${type} recorded for "${targetBook.title}". New stock: ${targetBook.quantity}`, "success");
        transForm.reset();
        renderAllViews();
    });

    clearBtn.addEventListener("click", () => {
        if (confirm("Are you sure you want to clear all transaction history?")) {
            localStorage.removeItem("library_transactions");
            showAlert("Transaction history log cleared.", "info");
            renderTransactionsTable();
        }
    });
}

function renderUsersTable() {
    const users = getUsersFromStorage();
    const tbody = document.getElementById("users-tbody");
    const countBadge = document.getElementById("user-count-badge");

    countBadge.textContent = `${users.length} Users`;
    tbody.innerHTML = "";

    if (users.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: #888;">No registered users.</td></tr>`;
        return;
    }

    users.forEach((user, index) => {
        const row = document.createElement("tr");

        let roleBadgeClass = "badge-role-member";
        if (user.role === "Admin") roleBadgeClass = "badge-role-admin";
        if (user.role === "Librarian") roleBadgeClass = "badge-role-librarian";

        row.innerHTML = `
            <td><strong>${escapeHtml(user.name)}</strong></td>
            <td><code>${escapeHtml(user.memberId)}</code></td>
            <td><span class="badge ${roleBadgeClass}">${escapeHtml(user.role)}</span></td>
            <td><small>${escapeHtml(user.date || "-")}</small></td>
            <td>
                <div class="action-btn-group">
                    <button class="btn btn-sm btn-primary" onclick="editUser(${index})">Update</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteUser(${index})">Delete</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function initUserForms() {
    const loginForm = document.getElementById("login-form");
    const logoutBtn = document.getElementById("logout-btn");

    loginForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const memberId = document.getElementById("login-member-id").value.trim();
        const password = document.getElementById("login-password").value.trim();

        const users = getUsersFromStorage();
        const foundUser = users.find(u => u.memberId.toLowerCase() === memberId.toLowerCase() && u.password === password);

        if (foundUser) {
            setCurrentUserSession(foundUser);
            showAlert(`Welcome back, ${foundUser.name}! (Role: ${foundUser.role})`, "success");
            updateUserStatusDisplay();
            loginForm.reset();
        } else {
            showAlert("Invalid Membership ID or Password. Please check and try again.", "danger");
        }
    });

    logoutBtn.addEventListener("click", () => {
        setCurrentUserSession(null);
        showAlert("You have successfully logged out.", "info");
        updateUserStatusDisplay();
    });

    const userForm = document.getElementById("user-form");
    const cancelUserBtn = document.getElementById("user-cancel-edit-btn");

    userForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const name = document.getElementById("user-fullname").value.trim();
        const memberId = document.getElementById("user-member-id").value.trim();
        const role = document.getElementById("user-role").value;
        const password = document.getElementById("user-password").value.trim();
        const editIndex = parseInt(document.getElementById("user-edit-index").value, 10);

        if (!name || !memberId || !role || !password) {
            showAlert("Please fill in all user registration fields.", "danger");
            return;
        }

        const users = getUsersFromStorage();
        const duplicate = users.find((u, idx) => u.memberId.toLowerCase() === memberId.toLowerCase() && idx !== editIndex);
        if (duplicate) {
            showAlert(`A user with Membership ID "${memberId}" already exists.`, "danger");
            return;
        }

        const today = new Date().toISOString().split('T')[0];

        if (editIndex >= 0 && editIndex < users.length) {
            users[editIndex] = {
                ...users[editIndex],
                name,
                memberId,
                role,
                password
            };
            saveUsersToStorage(users);
            showAlert(`User account for "${name}" updated successfully!`, "success");
            resetUserForm();
        } else {
            users.push({
                name,
                memberId,
                role,
                password,
                date: today
            });
            saveUsersToStorage(users);
            showAlert(`User "${name}" registered successfully as ${role}!`, "success");
            resetUserForm();
        }

        renderAllViews();
    });

    cancelUserBtn.addEventListener("click", resetUserForm);
}

function editUser(index) {
    const users = getUsersFromStorage();
    const user = users[index];
    if (!user) return;
    document.getElementById("user-edit-index").value = index;
    document.getElementById("user-fullname").value = user.name;
    document.getElementById("user-member-id").value = user.memberId;
    document.getElementById("user-role").value = user.role;
    document.getElementById("user-password").value = user.password;

    document.getElementById("user-form-heading").textContent = "Update User Details";
    document.getElementById("user-save-btn").textContent = "Update User";
    document.getElementById("user-cancel-edit-btn").style.display = "inline-block";

    document.getElementById("user-form").scrollIntoView({ behavior: "smooth" });
}

function deleteUser(index) {
    const users = getUsersFromStorage();
    const user = users[index];
    if (!user) return;
    const current = getCurrentUserSession();
    if (current && current.memberId === user.memberId) {
        showAlert("Cannot delete the currently logged-in user account!", "danger");
        return;
    }

    if (confirm(`Are you sure you want to delete user "${user.name}" (${user.memberId})?`)) {
        users.splice(index, 1);
        saveUsersToStorage(users);
        showAlert(`User "${user.name}" deleted.`, "info");
        resetUserForm();
        renderAllViews();
    }
}

function resetUserForm() {
    document.getElementById("user-form").reset();
    document.getElementById("user-edit-index").value = "-1";
    document.getElementById("user-form-heading").textContent = "Add New User";
    document.getElementById("user-save-btn").textContent = "Save User";
    document.getElementById("user-cancel-edit-btn").style.display = "none";
}

function updateUserStatusDisplay() {
    const current = getCurrentUserSession();
    const statusText = document.getElementById("logged-user-text");
    const logoutBtn = document.getElementById("logout-btn");

    if (current) {
        statusText.innerHTML = `Logged in as: <strong>${escapeHtml(current.name)}</strong> (${escapeHtml(current.role)})`;
        logoutBtn.style.display = "inline-block";
        const transUserInput = document.getElementById("trans-user-name");
        if (transUserInput && !transUserInput.value) {
            transUserInput.value = `${current.name} (${current.memberId})`;
        }
    } else {
        statusText.innerHTML = `Logged in as: <strong>Guest (Not Logged In)</strong>`;
        logoutBtn.style.display = "none";
    }
}

function escapeHtml(string) {
    if (string === null || string === undefined) return "";
    return String(string)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function renderAllViews() {
    renderDashboard();
    renderBooksTable();
    populateTransactionDropdowns();
    renderTransactionsTable();
    renderUsersTable();
    updateUserStatusDisplay();
}

document.addEventListener("DOMContentLoaded", () => {
    initNavigation();
    initBookForm();
    initTransactionForm();
    initUserForms();
    const searchInput = document.getElementById("dashboard-search-input");
    if (searchInput) {
        searchInput.addEventListener("input", renderDashboard);
    }
    renderAllViews();
});
