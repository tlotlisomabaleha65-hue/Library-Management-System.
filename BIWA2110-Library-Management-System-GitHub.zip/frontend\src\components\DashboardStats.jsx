import React from 'react';
import { BookMarked, Layers, AlertTriangle, ArrowUpRight, Users } from 'lucide-react';

export default function DashboardStats({ stats, loading }) {
    if (loading) {
        return (
            <div className="stats-grid">
                {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="stat-card skeleton-card">
                        <div className="skeleton-line skeleton-title"></div>
                        <div className="skeleton-line skeleton-value"></div>
                    </div>
                ))}
            </div>
        );
    }

    const {
        totalTitles = 0,
        totalCopiesInStock = 0,
        lowStockCount = 0,
        totalBorrowed = 0,
        totalUsers = 0
    } = stats || {};

    return (
        <div className="stats-grid">
            {/* Total Titles */}
            <div className="stat-card stat-primary">
                <div className="stat-icon-wrapper icon-blue">
                    <BookMarked size={24} />
                </div>
                <div className="stat-info">
                    <span className="stat-label">Unique Book Titles</span>
                    <span className="stat-value">{totalTitles}</span>
                    <span className="stat-subtext">Catalogued items</span>
                </div>
            </div>

            {/* Total Stock in Circulation */}
            <div className="stat-card stat-success">
                <div className="stat-icon-wrapper icon-green">
                    <Layers size={24} />
                </div>
                <div className="stat-info">
                    <span className="stat-label">Available Physical Copies</span>
                    <span className="stat-value">{totalCopiesInStock}</span>
                    <span className="stat-subtext">Copies currently on shelves</span>
                </div>
            </div>

            {/* Low Stock Warning */}
            <div className={`stat-card ${lowStockCount > 0 ? 'stat-warning-alert' : 'stat-neutral'}`}>
                <div className="stat-icon-wrapper icon-amber">
                    <AlertTriangle size={24} />
                </div>
                <div className="stat-info">
                    <span className="stat-label">Low Stock Warning</span>
                    <span className="stat-value">{lowStockCount}</span>
                    <span className="stat-subtext">&lt; 2 copies remaining</span>
                </div>
            </div>

            {/* Total Borrowed */}
            <div className="stat-card stat-purple">
                <div className="stat-icon-wrapper icon-purple">
                    <ArrowUpRight size={24} />
                </div>
                <div className="stat-info">
                    <span className="stat-label">Total Books Borrowed</span>
                    <span className="stat-value">{totalBorrowed}</span>
                    <span className="stat-subtext">All-time loans recorded</span>
                </div>
            </div>

            {/* Total Users */}
            <div className="stat-card stat-indigo">
                <div className="stat-icon-wrapper icon-indigo">
                    <Users size={24} />
                </div>
                <div className="stat-info">
                    <span className="stat-label">Library Members</span>
                    <span className="stat-value">{totalUsers}</span>
                    <span className="stat-subtext">Active accounts</span>
                </div>
            </div>
        </div>
    );
}
