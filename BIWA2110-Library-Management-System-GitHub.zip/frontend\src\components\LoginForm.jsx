import React, { useState } from 'react';
import { LogIn, Key, Mail, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';

export default function LoginForm({ onSuccess }) {
    const { login, loading } = useAuth();
    const { notifySuccess, notifyError } = useNotification();

    const [identifier, setIdentifier] = useState('');
    const [password, setPassword] = useState('');
    const [localError, setLocalError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLocalError('');

        if (!identifier.trim() || !password) {
            setLocalError('Please enter both Email/Membership ID and Password.');
            return;
        }

        const res = await login(identifier.trim(), password);
        if (res.success) {
            notifySuccess(`Signed in successfully as ${res.user.name} (${res.user.role})!`);
            if (onSuccess) onSuccess(res.user);
        } else {
            setLocalError(res.error || 'Authentication failed. Please check your credentials.');
            notifyError(res.error || 'Login failed.');
        }
    };

    // Quick-Fill Helper for Testing & Grading
    const quickFill = (id, pwd) => {
        setIdentifier(id);
        setPassword(pwd);
        setLocalError('');
    };

    return (
        <div className="card-container login-card">
            <div className="login-card-header">
                <div className="header-icon-box box-primary">
                    <LogIn size={22} />
                </div>
                <div>
                    <h3 className="section-title">User Authentication</h3>
                    <p className="section-subtitle">
                        Sign in to access admin tools, borrow books, and manage records.
                    </p>
                </div>
            </div>

            {localError && (
                <div className="alert-box alert-error">
                    <ShieldAlert size={18} />
                    <span>{localError}</span>
                </div>
            )}

            <form onSubmit={handleSubmit} className="form-grid">
                <div className="form-group col-span-2">
                    <label className="form-label">Email or Membership ID</label>
                    <div className="input-with-icon">
                        <Mail size={16} className="input-icon" />
                        <input
                            type="text"
                            value={identifier}
                            onChange={(e) => setIdentifier(e.target.value)}
                            placeholder="admin@limkokwing.ac.ls or ADM-001"
                            className="form-input"
                            disabled={loading}
                        />
                    </div>
                </div>

                <div className="form-group col-span-2">
                    <label className="form-label">Password</label>
                    <div className="input-with-icon">
                        <Key size={16} className="input-icon" />
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter password..."
                            className="form-input"
                            disabled={loading}
                        />
                    </div>
                </div>

                <div className="col-span-2">
                    <button
                        type="submit"
                        className="btn-primary w-full"
                        disabled={loading}
                    >
                        {loading ? (
                            <>
                                <span className="spinner-sm"></span>
                                <span>Authenticating...</span>
                            </>
                        ) : (
                            <>
                                <LogIn size={18} />
                                <span>Sign In to Account</span>
                            </>
                        )}
                    </button>
                </div>
            </form>

            {/* Quick Demo Credentials for Examiner */}
            <div className="demo-credentials-box">
                <div className="demo-header">
                    <Sparkles size={14} />
                    <span>Quick-Fill Demo Credentials (Click to test):</span>
                </div>
                <div className="demo-buttons">
                    <button
                        type="button"
                        className="demo-btn demo-btn-admin"
                        onClick={() => quickFill('admin@limkokwing.ac.ls', 'admin123')}
                    >
                        <strong>Admin:</strong> admin@limkokwing.ac.ls
                    </button>
                    <button
                        type="button"
                        className="demo-btn demo-btn-member"
                        onClick={() => quickFill('john.doe@student.limkokwing.ac.ls', 'password123')}
                    >
                        <strong>Member:</strong> john.doe (MEM-101)
                    </button>
                </div>
            </div>
        </div>
    );
}
