// Base API URL with fallback
const API_BASE_URL = 'http://localhost:5000/api';

async function request(endpoint, options = {}) {
    const config = {
        headers: {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        },
        ...options
    };

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || `Request failed with status ${response.status}`);
        }

        return data;
    } catch (err) {
        console.error(`API Error on [${options.method || 'GET'} ${endpoint}]:`, err.message);
        throw err;
    }
}

export const api = {
    // Health & System
    getHealth: () => request('/health'),

    // Books API
    getBooks: (search = '', genre = '') => {
        const params = new URLSearchParams();
        if (search) params.append('search', search);
        if (genre && genre !== 'All') params.append('genre', genre);
        const queryStr = params.toString() ? `?${params.toString()}` : '';
        return request(`/books${queryStr}`);
    },
    getBookById: (id) => request(`/books/${id}`),
    createBook: (bookData) => request('/books', {
        method: 'POST',
        body: JSON.stringify(bookData)
    }),
    updateBook: (id, bookData) => request(`/books/${id}`, {
        method: 'PUT',
        body: JSON.stringify(bookData)
    }),
    deleteBook: (id) => request(`/books/${id}`, {
        method: 'DELETE'
    }),

    // Transactions API
    getTransactions: () => request('/transactions'),
    getStats: () => request('/transactions/stats'),
    createTransaction: (txData) => request('/transactions', {
        method: 'POST',
        body: JSON.stringify(txData)
    }),

    // Users API
    getUsers: () => request('/users'),
    getUserById: (id) => request(`/users/${id}`),
    createUser: (userData) => request('/users', {
        method: 'POST',
        body: JSON.stringify(userData)
    }),
    updateUser: (id, userData) => request(`/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(userData)
    }),
    deleteUser: (id) => request(`/users/${id}`, {
        method: 'DELETE'
    }),
    login: (credentials) => request('/users/login', {
        method: 'POST',
        body: JSON.stringify(credentials)
    })
};
