import React, { useState } from 'react';
import { PlusCircle, RotateCcw, BookPlus, AlertCircle } from 'lucide-react';

const COMMON_GENRES = [
    'Computer Science',
    'Programming',
    'Web Development',
    'Software Engineering',
    'Databases',
    'Information Technology',
    'Business & Management',
    'Cybersecurity',
    'Artificial Intelligence',
    'Mathematics'
];

export default function AddBookForm({ onBookAdded, submitting = false }) {
    const [formData, setFormData] = useState({
        title: '',
        author: '',
        genre: 'Computer Science',
        isbn: '',
        quantity: 1
    });

    const [errors, setErrors] = useState({});

    // Controlled inputs handler
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value
        }));

        // Clear error for field on change
        if (errors[name]) {
            setErrors((prev) => ({ ...prev, [name]: null }));
        }
    };

    // Form validation
    const validate = () => {
        const newErrors = {};

        if (!formData.title.trim()) {
            newErrors.title = 'Title is required';
        } else if (formData.title.trim().length < 2) {
            newErrors.title = 'Title must be at least 2 characters';
        }

        if (!formData.author.trim()) {
            newErrors.author = 'Author name is required';
        }

        if (!formData.genre.trim()) {
            newErrors.genre = 'Genre is required';
        }

        if (!formData.isbn.trim()) {
            newErrors.isbn = 'ISBN is required';
        } else {
            const cleanIsbn = formData.isbn.trim().replace(/[-\s]/g, '');
            if (cleanIsbn.length < 10 || cleanIsbn.length > 17) {
                newErrors.isbn = 'ISBN should be 10 or 13 digits (hyphens allowed)';
            }
        }

        const qty = parseInt(formData.quantity, 10);
        if (isNaN(qty) || qty < 0) {
            newErrors.quantity = 'Initial quantity must be 0 or a positive number';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    // Submit handler
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        const success = await onBookAdded({
            title: formData.title.trim(),
            author: formData.author.trim(),
            genre: formData.genre.trim(),
            isbn: formData.isbn.trim(),
            quantity: parseInt(formData.quantity, 10)
        });

        if (success) {
            // Reset form
            setFormData({
                title: '',
                author: '',
                genre: 'Computer Science',
                isbn: '',
                quantity: 1
            });
            setErrors({});
        }
    };

    const handleReset = () => {
        setFormData({
            title: '',
            author: '',
            genre: 'Computer Science',
            isbn: '',
            quantity: 1
        });
        setErrors({});
    };

    return (
        <div className="card-container form-card">
            <div className="form-card-header">
                <div className="header-icon-box">
                    <BookPlus size={20} />
                </div>
                <div>
                    <h3 className="section-title">Add New Book to Catalog</h3>
                    <p className="section-subtitle">
                        Enter the book's metadata and initial inventory count.
                    </p>
                </div>
            </div>

            <form onSubmit={handleSubmit} noValidate className="form-grid">
                {/* Book Title */}
                <div className="form-group col-span-2">
                    <label htmlFor="title" className="form-label">
                        Book Title <span className="required-star">*</span>
                    </label>
                    <input
                        type="text"
                        id="title"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        placeholder="e.g. Modern Web Development with React and Node.js"
                        className={`form-input ${errors.title ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.title && (
                        <span className="error-message">
                            <AlertCircle size={13} /> {errors.title}
                        </span>
                    )}
                </div>

                {/* Author */}
                <div className="form-group">
                    <label htmlFor="author" className="form-label">
                        Author(s) <span className="required-star">*</span>
                    </label>
                    <input
                        type="text"
                        id="author"
                        name="author"
                        value={formData.author}
                        onChange={handleChange}
                        placeholder="e.g. Dr. Alan Turing"
                        className={`form-input ${errors.author ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.author && (
                        <span className="error-message">
                            <AlertCircle size={13} /> {errors.author}
                        </span>
                    )}
                </div>

                {/* Genre */}
                <div className="form-group">
                    <label htmlFor="genre" className="form-label">
                        Genre / Category <span className="required-star">*</span>
                    </label>
                    <select
                        id="genre"
                        name="genre"
                        value={formData.genre}
                        onChange={handleChange}
                        className={`form-select ${errors.genre ? 'input-error' : ''}`}
                        disabled={submitting}
                    >
                        {COMMON_GENRES.map((g) => (
                            <option key={g} value={g}>{g}</option>
                        ))}
                    </select>
                    {errors.genre && (
                        <span className="error-message">
                            <AlertCircle size={13} /> {errors.genre}
                        </span>
                    )}
                </div>

                {/* ISBN */}
                <div className="form-group">
                    <label htmlFor="isbn" className="form-label">
                        ISBN Identifier <span className="required-star">*</span>
                    </label>
                    <input
                        type="text"
                        id="isbn"
                        name="isbn"
                        value={formData.isbn}
                        onChange={handleChange}
                        placeholder="e.g. 978-0-13-235088-4"
                        className={`form-input ${errors.isbn ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.isbn && (
                        <span className="error-message">
                            <AlertCircle size={13} /> {errors.isbn}
                        </span>
                    )}
                </div>

                {/* Initial Quantity */}
                <div className="form-group">
                    <label htmlFor="quantity" className="form-label">
                        Initial Quantity in Stock <span className="required-star">*</span>
                    </label>
                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        min="0"
                        step="1"
                        value={formData.quantity}
                        onChange={handleChange}
                        className={`form-input ${errors.quantity ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.quantity && (
                        <span className="error-message">
                            <AlertCircle size={13} /> {errors.quantity}
                        </span>
                    )}
                </div>

                {/* Action Buttons */}
                <div className="form-actions col-span-2">
                    <button
                        type="button"
                        onClick={handleReset}
                        className="btn-secondary"
                        disabled={submitting}
                    >
                        <RotateCcw size={16} />
                        <span>Reset Form</span>
                    </button>

                    <button
                        type="submit"
                        className="btn-primary"
                        disabled={submitting}
                    >
                        {submitting ? (
                            <>
                                <span className="spinner-sm"></span>
                                <span>Saving Book...</span>
                            </>
                        ) : (
                            <>
                                <PlusCircle size={16} />
                                <span>Add Book to Catalog</span>
                            </>
                        )}
                    </button>
                </div>
            </form>
        </div>
    );
}
