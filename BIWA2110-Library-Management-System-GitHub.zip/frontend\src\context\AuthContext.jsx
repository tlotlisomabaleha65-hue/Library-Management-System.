import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
    const [user, setUser] = useState(() => {
        try {
            const saved = localStorage.getItem('biwa2110_library_user');
            return saved ? JSON.parse(saved) : null;
        } catch {
            return null;
        }
    });
    const [loading, setLoading] = useState(false);
    const [authError, setAuthError] = useState(null);

    const login = async (identifier, password) => {
        setLoading(true);
        setAuthError(null);
        try {
            const res = await api.login({ identifier, password });
            if (res.success && res.user) {
                setUser(res.user);
                localStorage.setItem('biwa2110_library_user', JSON.stringify(res.user));
                return { success: true, user: res.user };
            } else {
                throw new Error(res.message || 'Login failed');
            }
        } catch (err) {
            setAuthError(err.message);
            return { success: false, error: err.message };
        } finally {
            setLoading(false);
        }
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('biwa2110_library_user');
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, loading, authError, setAuthError }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
