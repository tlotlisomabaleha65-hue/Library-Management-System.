import React, { useState, useMemo } from 'react';
import { Search, Filter, Edit3, Trash2, BookOpen, AlertCircle, CheckCircle2, LayoutGrid, Table as TableIcon } from 'lucide-react';

export default function BookList({
    books = [],
    loading = false,
    onEdit = null,
    onDelete = null,
    onQuickStock = null,
    showActions = true,
    title = 'Books Catalog'
}) {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedGenre, setSelectedGenre] = useState('All');
    const [viewMode, setViewMode] = useState('table'); // 'table' or 'card'

    // Extract unique genres for filter dropdown
    const genres = useMemo(() => {
        const set = new Set(books.map((b) => b.genre).filter(Boolean));
        return ['All', ...Array.from(set).sort()];
    }, [books]);

    // Filter books locally by search term & genre
    const filteredBooks = useMemo(() => {
        return books.filter((book) => {
            const matchesSearch =
                !searchTerm.trim() ||
                book.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                book.author?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                book.isbn?.toLowerCase().includes(searchTerm.toLowerCase());

            const matchesGenre =
                selectedGenre === 'All' || book.genre === selectedGenre;

            return matchesSearch && matchesGenre;
        });
    }, [books, searchTerm, selectedGenre]);

    const getStockBadge = (quantity) => {
        const qty = parseInt(quantity, 10);
        if (qty === 0) {
            return (
                <span className="badge badge-out-of-stock">
                    <AlertCircle size={13} />
                    <span>Out of Stock (0)</span>
                </span>
            );
        }
        if (qty < 2) {
            return (
                <span className="badge badge-low-stock">
                    <AlertCircle size={13} />
                    <span>Low Stock ({qty} copy)</span>
                </span>
            );
        }
        return (
            <span className="badge badge-in-stock">
                <CheckCircle2 size={13} />
                <span>Available ({qty} copies)</span>
            </span>
        );
    };

    if (loading) {
        return (
            <div className="card-container">
                <div className="loading-state">
                    <div className="spinner"></div>
                    <p>Loading books from database...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="card-container">
            {/* Header with Title and Search/Filters */}
            <div className="card-header-flex">
                <div className="card-title-group">
                    <h2 className="section-title">{title}</h2>
                    <span className="count-pill">{filteredBooks.length} items</span>
                </div>

                <div className="filter-controls">
                    {/* Search Input */}
                    <div className="search-bar">
                        <Search size={18} className="search-icon" />
                        <input
                            type="text"
                            placeholder="Search by title, author, or ISBN..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="input-search"
                        />
                        {searchTerm && (
                            <button
                                className="search-clear-btn"
                                onClick={() => setSearchTerm('')}
                                title="Clear search"
                            >
                                &times;
                            </button>
                        )}
                    </div>

                    {/* Genre Filter */}
                    <div className="genre-filter">
                        <Filter size={16} className="filter-icon" />
                        <select
                            value={selectedGenre}
                            onChange={(e) => setSelectedGenre(e.target.value)}
                            className="select-filter"
                        >
                            {genres.map((g) => (
                                <option key={g} value={g}>
                                    {g === 'All' ? 'All Genres' : g}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* View Switcher */}
                    <div className="view-switcher">
                        <button
                            type="button"
                            className={`btn-view-toggle ${viewMode === 'table' ? 'active' : ''}`}
                            onClick={() => setViewMode('table')}
                            title="Table view"
                        >
                            <TableIcon size={18} />
                        </button>
                        <button
                            type="button"
                            className={`btn-view-toggle ${viewMode === 'card' ? 'active' : ''}`}
                            onClick={() => setViewMode('card')}
                            title="Card view"
                        >
                            <LayoutGrid size={18} />
                        </button>
                    </div>
                </div>
            </div>

            {/* Empty State */}
            {filteredBooks.length === 0 ? (
                <div className="empty-state">
                    <BookOpen size={48} className="empty-icon" />
                    <h3>No Books Found</h3>
                    <p>
                        {searchTerm || selectedGenre !== 'All'
                            ? 'No titles matched your search criteria. Try clearing the filters.'
                            : 'There are currently no books in the catalog. Add a new book using the form above.'}
                    </p>
                </div>
            ) : viewMode === 'table' ? (
                /* Table View */
                <div className="table-responsive">
                    <table className="custom-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title & Author</th>
                                <th>Genre</th>
                                <th>ISBN</th>
                                <th>Stock Status</th>
                                {showActions && <th className="text-right">Actions</th>}
                            </tr>
                        </thead>
                        <tbody>
                            {filteredBooks.map((book, idx) => {
                                const isLowStock = parseInt(book.quantity, 10) < 2;
                                return (
                                    <tr
                                        key={book.id}
                                        className={isLowStock ? 'row-highlight-low-stock' : ''}
                                    >
                                        <td className="cell-id">{idx + 1}</td>
                                        <td>
                                            <div className="book-cell-info">
                                                <span className="book-title-cell">{book.title}</span>
                                                <span className="book-author-cell">by {book.author}</span>
                                            </div>
                                        </td>
                                        <td>
                                            <span className="genre-tag">{book.genre}</span>
                                        </td>
                                        <td>
                                            <code className="isbn-tag">{book.isbn}</code>
                                        </td>
                                        <td>
                                            {getStockBadge(book.quantity)}
                                        </td>
                                        {showActions && (
                                            <td className="text-right actions-cell">
                                                {onQuickStock && (
                                                    <button
                                                        onClick={() => onQuickStock(book)}
                                                        className="btn-action btn-action-stock"
                                                        title="Quick Stock Adjust"
                                                    >
                                                        Adjust Stock
                                                    </button>
                                                )}
                                                {onEdit && (
                                                    <button
                                                        onClick={() => onEdit(book)}
                                                        className="btn-action btn-action-edit"
                                                        title="Update Book"
                                                    >
                                                        <Edit3 size={15} />
                                                        <span>Update</span>
                                                    </button>
                                                )}
                                                {onDelete && (
                                                    <button
                                                        onClick={() => onDelete(book)}
                                                        className="btn-action btn-action-delete"
                                                        title="Delete Book"
                                                    >
                                                        <Trash2 size={15} />
                                                        <span>Delete</span>
                                                    </button>
                                                )}
                                            </td>
                                        )}
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            ) : (
                /* Card Grid View */
                <div className="books-card-grid">
                    {filteredBooks.map((book) => {
                        const isLowStock = parseInt(book.quantity, 10) < 2;
                        return (
                            <div
                                key={book.id}
                                className={`book-card ${isLowStock ? 'book-card-low-stock' : ''}`}
                            >
                                <div className="book-card-header">
                                    <span className="genre-tag">{book.genre}</span>
                                    {getStockBadge(book.quantity)}
                                </div>
                                <h3 className="book-card-title">{book.title}</h3>
                                <p className="book-card-author">By {book.author}</p>
                                <div className="book-card-meta">
                                    <span className="meta-label">ISBN:</span>
                                    <code className="isbn-tag">{book.isbn}</code>
                                </div>

                                {showActions && (
                                    <div className="book-card-footer">
                                        {onQuickStock && (
                                            <button
                                                onClick={() => onQuickStock(book)}
                                                className="btn-action btn-action-stock w-full"
                                            >
                                                Adjust Stock
                                            </button>
                                        )}
                                        <div className="card-btn-row">
                                            {onEdit && (
                                                <button
                                                    onClick={() => onEdit(book)}
                                                    className="btn-action btn-action-edit"
                                                >
                                                    <Edit3 size={14} /> Update
                                                </button>
                                            )}
                                            {onDelete && (
                                                <button
                                                    onClick={() => onDelete(book)}
                                                    className="btn-action btn-action-delete"
                                                >
                                                    <Trash2 size={14} /> Delete
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
