import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import TransactionForm from '../components/TransactionForm';
import TransactionHistory from '../components/TransactionHistory';
import { useNotification } from '../context/NotificationContext';
import { useAuth } from '../context/AuthContext';
import { ArrowLeftRight, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';

export default function Transactions() {
    const [books, setBooks] = useState([]);
    const [users, setUsers] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);

    const { notifySuccess, notifyError } = useNotification();
    const { user } = useAuth();

    const loadAll = async () => {
        setLoading(true);
        try {
            const [bRes, uRes, tRes] = await Promise.all([
                api.getBooks(),
                api.getUsers(),
                api.getTransactions()
            ]);

            if (bRes.success) setBooks(bRes.data);
            if (uRes.success) setUsers(uRes.data);
            if (tRes.success) setTransactions(tRes.data);
        } catch (err) {
            notifyError('Error fetching data: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadAll();
    }, []);

    // Transaction submit handler
    const handleTransaction = async (txData) => {
        setSubmitting(true);
        try {
            // Default user_id to currently logged in user if not specified
            const payload = {
                ...txData,
                user_id: txData.user_id || (user ? user.id : null)
            };

            const res = await api.createTransaction(payload);
            if (res.success) {
                notifySuccess(res.message);
                // Reload books and transaction log to reflect updated stock instantly
                await loadAll();
                return true;
            }
        } catch (err) {
            notifyError('Transaction failed: ' + err.message);
            return false;
        } finally {
            setSubmitting(false);
        }
    };

    // Calculate quick counts
    const totalCopies = books.reduce((s, b) => s + (parseInt(b.quantity, 10) || 0), 0);
    const lowStockCount = books.filter((b) => (parseInt(b.quantity, 10) || 0) < 2).length;

    return (
        <div className="page-container">
            <div className="page-header">
                <div>
                    <h1 className="page-title">Availability & Transaction Management</h1>
                    <p className="page-subtitle">
                        Adjust physical inventory, record student borrowings, and audit stock history.
                    </p>
                </div>
            </div>

            {/* Quick Summary Pill Bar */}
            <div className="tx-overview-bar">
                <div className="overview-item">
                    <Layers size={18} className="text-primary" />
                    <span>Total Copies on Shelves: <strong>{totalCopies}</strong></span>
                </div>
                <div className="overview-item">
                    <AlertTriangle size={18} className={lowStockCount > 0 ? 'text-amber' : 'text-muted'} />
                    <span>Titles with Low Stock (&lt; 2): <strong>{lowStockCount}</strong></span>
                </div>
                <div className="overview-item">
                    <ArrowLeftRight size={18} className="text-purple" />
                    <span>Total Operations Logged: <strong>{transactions.length}</strong></span>
                </div>
            </div>

            {/* Top: Transaction Form (Buttons or forms to add/deduct stock) */}
            <div className="mb-8">
                <TransactionForm
                    books={books}
                    users={users}
                    onTransactionComplete={handleTransaction}
                    submitting={submitting}
                />
            </div>

            {/* Bottom: Transaction History Log */}
            <div className="mb-8">
                <TransactionHistory
                    transactions={transactions}
                    loading={loading}
                />
            </div>
        </div>
    );
}
