@echo off
echo ========================================================
echo   BIWA2110 - Library Management System
echo   Limkokwing University of Creative Technology
echo ========================================================
echo.
echo Starting Backend (Express.js on port 5000)...
start "BIWA2110 Backend Server" cmd /k "cd backend && npm start"

echo Starting Frontend (React Vite on port 3000)...
start "BIWA2110 Frontend App" cmd /k "cd frontend && npm run dev"

echo.
echo Both servers are launching!
echo Frontend will be accessible at: http://localhost:3000
echo Backend API will be accessible at: http://localhost:5000
echo ========================================================
