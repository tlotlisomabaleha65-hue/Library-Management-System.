import React, { createContext, useContext, useState, useCallback } from 'react';

const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
    const [notifications, setNotifications] = useState([]);

    const addNotification = useCallback((message, type = 'info', duration = 4000) => {
        const id = Date.now() + Math.random().toString(36).substr(2, 4);
        setNotifications((prev) => [...prev, { id, message, type }]);

        setTimeout(() => {
            setNotifications((prev) => prev.filter((n) => n.id !== id));
        }, duration);
    }, []);

    const removeNotification = useCallback((id) => {
        setNotifications((prev) => prev.filter((n) => n.id !== id));
    }, []);

    const notifySuccess = (msg) => addNotification(msg, 'success');
    const notifyError = (msg) => addNotification(msg, 'error');
    const notifyWarning = (msg) => addNotification(msg, 'warning');
    const notifyInfo = (msg) => addNotification(msg, 'info');

    return (
        <NotificationContext.Provider
            value={{ addNotification, notifySuccess, notifyError, notifyWarning, notifyInfo }}
        >
            {children}
            <div className="toast-container">
                {notifications.map((n) => (
                    <div key={n.id} className={`toast-card toast-${n.type}`}>
                        <div className="toast-content">
                            <span className="toast-indicator"></span>
                            <span className="toast-message">{n.message}</span>
                        </div>
                        <button
                            className="toast-close"
                            onClick={() => removeNotification(n.id)}
                            aria-label="Close notification"
                        >
                            &times;
                        </button>
                    </div>
                ))}
            </div>
        </NotificationContext.Provider>
    );
}

export function useNotification() {
    const context = useContext(NotificationContext);
    if (!context) {
        throw new Error('useNotification must be used within a NotificationProvider');
    }
    return context;
}
