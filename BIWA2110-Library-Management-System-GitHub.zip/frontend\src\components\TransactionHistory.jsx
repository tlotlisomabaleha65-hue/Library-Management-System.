import React, { useState, useMemo } from 'react';
import { History, Search, Filter, ArrowUpRight, ArrowDownLeft, Calendar, FileText } from 'lucide-react';

export default function TransactionHistory({ transactions = [], loading = false }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterType, setFilterType] = useState('All');

    const filteredTransactions = useMemo(() => {
        return transactions.filter((tx) => {
            const matchesSearch =
                !searchTerm.trim() ||
                tx.book_title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                tx.book_isbn?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                tx.user_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                tx.membership_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                tx.notes?.toLowerCase().includes(searchTerm.toLowerCase());

            const matchesType =
                filterType === 'All' || tx.transaction_type === filterType;

            return matchesSearch && matchesType;
        });
    }, [transactions, searchTerm, filterType]);

    const formatDate = (dateStr) => {
        if (!dateStr) return 'N/A';
        try {
            const d = new Date(dateStr);
            return d.toLocaleString('en-GB', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch {
            return dateStr;
        }
    };

    if (loading) {
        return (
            <div className="card-container">
                <div className="loading-state">
                    <div className="spinner"></div>
                    <p>Loading transaction history...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="card-container">
            <div className="card-header-flex">
                <div className="card-title-group">
                    <h3 className="section-title">
                        <History size={20} className="inline-icon" /> Stock & Borrowing History Log
                    </h3>
                    <span className="count-pill">{filteredTransactions.length} records</span>
                </div>

                <div className="filter-controls">
                    {/* Search */}
                    <div className="search-bar">
                        <Search size={18} className="search-icon" />
                        <input
                            type="text"
                            placeholder="Search book, member, or notes..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="input-search"
                        />
                        {searchTerm && (
                            <button
                                className="search-clear-btn"
                                onClick={() => setSearchTerm('')}
                            >
                                &times;
                            </button>
                        )}
                    </div>

                    {/* Filter Type */}
                    <div className="genre-filter">
                        <Filter size={16} className="filter-icon" />
                        <select
                            value={filterType}
                            onChange={(e) => setFilterType(e.target.value)}
                            className="select-filter"
                        >
                            <option value="All">All Operations</option>
                            <option value="BORROW_STOCK">Borrowed Stock</option>
                            <option value="ADD_STOCK">Added Stock</option>
                        </select>
                    </div>
                </div>
            </div>

            {filteredTransactions.length === 0 ? (
                <div className="empty-state">
                    <FileText size={48} className="empty-icon" />
                    <h3>No Transactions Recorded</h3>
                    <p>
                        {searchTerm || filterType !== 'All'
                            ? 'No transaction logs match your search filters.'
                            : 'No stock adjustments or borrowing operations have been recorded yet.'}
                    </p>
                </div>
            ) : (
                <div className="table-responsive">
                    <table className="custom-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Timestamp</th>
                                <th>Type</th>
                                <th>Book Details</th>
                                <th>Quantity</th>
                                <th>Member / User</th>
                                <th>Notes / Purpose</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredTransactions.map((tx, idx) => {
                                const isAdd = tx.transaction_type === 'ADD_STOCK';
                                return (
                                    <tr key={tx.id || idx}>
                                        <td className="cell-id">#{tx.id}</td>
                                        <td className="cell-date">
                                            <div className="date-wrapper">
                                                <Calendar size={13} />
                                                <span>{formatDate(tx.created_at)}</span>
                                            </div>
                                        </td>
                                        <td>
                                            {isAdd ? (
                                                <span className="badge badge-add-stock">
                                                    <ArrowUpRight size={14} /> Added Stock
                                                </span>
                                            ) : (
                                                <span className="badge badge-borrow-stock">
                                                    <ArrowDownLeft size={14} /> Borrowed Stock
                                                </span>
                                            )}
                                        </td>
                                        <td>
                                            <div className="book-cell-info">
                                                <span className="book-title-cell">{tx.book_title || 'Unknown Title'}</span>
                                                {tx.book_isbn && (
                                                    <span className="book-author-cell">ISBN: {tx.book_isbn}</span>
                                                )}
                                            </div>
                                        </td>
                                        <td>
                                            <span className={`qty-indicator ${isAdd ? 'qty-plus' : 'qty-minus'}`}>
                                                {isAdd ? `+${tx.quantity}` : `-${tx.quantity}`}
                                            </span>
                                        </td>
                                        <td>
                                            {tx.user_name ? (
                                                <div className="user-cell-info">
                                                    <span className="user-name-text">{tx.user_name}</span>
                                                    <span className="user-id-subtext">{tx.membership_id}</span>
                                                </div>
                                            ) : (
                                                <span className="text-muted">Staff / General</span>
                                            )}
                                        </td>
                                        <td>
                                            <span className="tx-notes">{tx.notes || '—'}</span>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
