import React, { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { BookOpen, LayoutDashboard, ArrowLeftRight, Users, LogIn, LogOut, Menu, X, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';

export default function Navbar() {
    const { user, logout } = useAuth();
    const { notifyInfo } = useNotification();
    const navigate = useNavigate();
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    const handleLogout = () => {
        logout();
        notifyInfo('You have logged out.');
        navigate('/login');
    };

    const closeMobile = () => setMobileMenuOpen(false);

    return (
        <header className="navbar-header">
            <div className="navbar-container">
                {/* Brand / Logo */}
                <Link to="/" className="navbar-brand" onClick={closeMobile}>
                    <div className="brand-logo-box">
                        <BookOpen className="brand-icon" size={24} />
                    </div>
                    <div className="brand-text">
                        <span className="brand-title">LIMKOKWING</span>
                        <span className="brand-subtitle">BIWA2110 • Library Portal</span>
                    </div>
                </Link>

                {/* Mobile Toggle Button */}
                <button
                    className="mobile-toggle-btn"
                    onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    aria-label="Toggle navigation menu"
                >
                    {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>

                {/* Navigation Links */}
                <nav className={`nav-links ${mobileMenuOpen ? 'mobile-open' : ''}`}>
                    <NavLink
                        to="/"
                        end
                        className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                        onClick={closeMobile}
                    >
                        <LayoutDashboard size={18} />
                        <span>Dashboard</span>
                    </NavLink>

                    <NavLink
                        to="/books"
                        className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                        onClick={closeMobile}
                    >
                        <BookOpen size={18} />
                        <span>Book Management</span>
                    </NavLink>

                    <NavLink
                        to="/transactions"
                        className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                        onClick={closeMobile}
                    >
                        <ArrowLeftRight size={18} />
                        <span>Transactions & Stock</span>
                    </NavLink>

                    <NavLink
                        to="/users"
                        className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                        onClick={closeMobile}
                    >
                        <Users size={18} />
                        <span>User Management</span>
                    </NavLink>

                    {/* User Profile / Auth Actions */}
                    <div className="nav-auth-section">
                        {user ? (
                            <div className="user-profile-badge">
                                <div className="user-avatar">
                                    {user.name.charAt(0).toUpperCase()}
                                </div>
                                <div className="user-details-mini">
                                    <span className="user-name">{user.name}</span>
                                    <span className="user-role-tag">
                                        <ShieldCheck size={12} /> {user.role} ({user.membership_id})
                                    </span>
                                </div>
                                <button
                                    onClick={handleLogout}
                                    className="btn-logout"
                                    title="Logout"
                                >
                                    <LogOut size={16} />
                                    <span>Logout</span>
                                </button>
                            </div>
                        ) : (
                            <Link to="/login" className="btn-login-nav" onClick={closeMobile}>
                                <LogIn size={18} />
                                <span>Sign In</span>
                            </Link>
                        )}
                    </div>
                </nav>
            </div>
        </header>
    );
}
