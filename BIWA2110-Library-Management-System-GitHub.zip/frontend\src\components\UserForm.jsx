import React, { useState } from 'react';
import { UserPlus, RotateCcw, AlertCircle, Shield } from 'lucide-react';

export default function UserForm({ onUserAdded, submitting = false }) {
    const [formData, setFormData] = useState({
        name: '',
        membership_id: '',
        role: 'Member',
        email: '',
        password: ''
    });

    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        if (errors[name]) {
            setErrors((prev) => ({ ...prev, [name]: null }));
        }
    };

    const validate = () => {
        const newErrors = {};

        if (!formData.name.trim()) {
            newErrors.name = 'Full name is required';
        }

        if (!formData.membership_id.trim()) {
            newErrors.membership_id = 'Membership ID is required (e.g. MEM-105)';
        }

        if (!formData.email.trim()) {
            newErrors.email = 'Email address is required';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
            newErrors.email = 'Please enter a valid email format';
        }

        if (!formData.password || formData.password.length < 4) {
            newErrors.password = 'Password must be at least 4 characters';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        const success = await onUserAdded({
            name: formData.name.trim(),
            membership_id: formData.membership_id.trim().toUpperCase(),
            role: formData.role,
            email: formData.email.trim().toLowerCase(),
            password: formData.password
        });

        if (success) {
            setFormData({
                name: '',
                membership_id: '',
                role: 'Member',
                email: '',
                password: ''
            });
            setErrors({});
        }
    };

    const handleReset = () => {
        setFormData({
            name: '',
            membership_id: '',
            role: 'Member',
            email: '',
            password: ''
        });
        setErrors({});
    };

    return (
        <div className="card-container form-card">
            <div className="form-card-header">
                <div className="header-icon-box box-indigo">
                    <UserPlus size={20} />
                </div>
                <div>
                    <h3 className="section-title">Register New User</h3>
                    <p className="section-subtitle">
                        Add a new student member, faculty librarian, or system admin.
                    </p>
                </div>
            </div>

            <form onSubmit={handleSubmit} noValidate className="form-grid">
                {/* Full Name */}
                <div className="form-group col-span-2">
                    <label htmlFor="name" className="form-label">
                        Full Name <span className="required-star">*</span>
                    </label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="e.g. Neo Khama"
                        className={`form-input ${errors.name ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.name && (
                        <span className="error-message"><AlertCircle size={13} /> {errors.name}</span>
                    )}
                </div>

                {/* Membership ID */}
                <div className="form-group">
                    <label htmlFor="membership_id" className="form-label">
                        Membership ID <span className="required-star">*</span>
                    </label>
                    <input
                        type="text"
                        id="membership_id"
                        name="membership_id"
                        value={formData.membership_id}
                        onChange={handleChange}
                        placeholder="e.g. MEM-104 or ADM-002"
                        className={`form-input ${errors.membership_id ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.membership_id && (
                        <span className="error-message"><AlertCircle size={13} /> {errors.membership_id}</span>
                    )}
                </div>

                {/* Role */}
                <div className="form-group">
                    <label htmlFor="role" className="form-label">
                        System Role <span className="required-star">*</span>
                    </label>
                    <select
                        id="role"
                        name="role"
                        value={formData.role}
                        onChange={handleChange}
                        className="form-select"
                        disabled={submitting}
                    >
                        <option value="Member">Member (Student / General)</option>
                        <option value="Librarian">Librarian (Staff)</option>
                        <option value="Admin">Admin (Full Control)</option>
                    </select>
                </div>

                {/* Email */}
                <div className="form-group">
                    <label htmlFor="email" className="form-label">
                        Email Address <span className="required-star">*</span>
                    </label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="e.g. user@student.limkokwing.ac.ls"
                        className={`form-input ${errors.email ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.email && (
                        <span className="error-message"><AlertCircle size={13} /> {errors.email}</span>
                    )}
                </div>

                {/* Password */}
                <div className="form-group">
                    <label htmlFor="password" className="form-label">
                        Password <span className="required-star">*</span>
                    </label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Minimum 4 characters"
                        className={`form-input ${errors.password ? 'input-error' : ''}`}
                        disabled={submitting}
                    />
                    {errors.password && (
                        <span className="error-message"><AlertCircle size={13} /> {errors.password}</span>
                    )}
                </div>

                {/* Actions */}
                <div className="form-actions col-span-2">
                    <button
                        type="button"
                        onClick={handleReset}
                        className="btn-secondary"
                        disabled={submitting}
                    >
                        <RotateCcw size={16} />
                        <span>Reset</span>
                    </button>

                    <button
                        type="submit"
                        className="btn-primary"
                        disabled={submitting}
                    >
                        {submitting ? (
                            <>
                                <span className="spinner-sm"></span>
                                <span>Registering User...</span>
                            </>
                        ) : (
                            <>
                                <UserPlus size={16} />
                                <span>Create User Account</span>
                            </>
                        )}
                    </button>
                </div>
            </form>
        </div>
    );
}
