import React, { useState, useEffect } from 'react';
import { X, Save, AlertCircle } from 'lucide-react';

export default function EditUserModal({ user, isOpen, onClose, onSave, submitting = false }) {
    const [formData, setFormData] = useState({
        name: '',
        membership_id: '',
        role: 'Member',
        email: '',
        password: ''
    });
    const [errors, setErrors] = useState({});

    useEffect(() => {
        if (user) {
            setFormData({
                name: user.name || '',
                membership_id: user.membership_id || '',
                role: user.role || 'Member',
                email: user.email || '',
                password: ''
            });
            setErrors({});
        }
    }, [user]);

    if (!isOpen || !user) return null;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        if (errors[name]) {
            setErrors((prev) => ({ ...prev, [name]: null }));
        }
    };

    const validate = () => {
        const newErrors = {};
        if (!formData.name.trim()) newErrors.name = 'Full name is required';
        if (!formData.membership_id.trim()) newErrors.membership_id = 'Membership ID is required';
        if (!formData.email.trim()) newErrors.email = 'Email address is required';

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        await onSave(user.id, {
            name: formData.name.trim(),
            membership_id: formData.membership_id.trim().toUpperCase(),
            role: formData.role,
            email: formData.email.trim().toLowerCase(),
            password: formData.password ? formData.password.trim() : undefined
        });
    };

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-container" onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                    <div>
                        <h3 className="modal-title">Update User Details</h3>
                        <p className="modal-subtitle">ID #{user.id} • {user.membership_id}</p>
                    </div>
                    <button className="modal-close-btn" onClick={onClose} aria-label="Close">
                        <X size={20} />
                    </button>
                </div>

                <form onSubmit={handleSubmit} noValidate className="modal-body form-grid">
                    <div className="form-group col-span-2">
                        <label className="form-label">Full Name *</label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            className={`form-input ${errors.name ? 'input-error' : ''}`}
                            disabled={submitting}
                        />
                        {errors.name && (
                            <span className="error-message"><AlertCircle size={13} /> {errors.name}</span>
                        )}
                    </div>

                    <div className="form-group">
                        <label className="form-label">Membership ID *</label>
                        <input
                            type="text"
                            name="membership_id"
                            value={formData.membership_id}
                            onChange={handleChange}
                            className={`form-input ${errors.membership_id ? 'input-error' : ''}`}
                            disabled={submitting}
                        />
                        {errors.membership_id && (
                            <span className="error-message"><AlertCircle size={13} /> {errors.membership_id}</span>
                        )}
                    </div>

                    <div className="form-group">
                        <label className="form-label">Role *</label>
                        <select
                            name="role"
                            value={formData.role}
                            onChange={handleChange}
                            className="form-select"
                            disabled={submitting}
                        >
                            <option value="Member">Member</option>
                            <option value="Librarian">Librarian</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </div>

                    <div className="form-group col-span-2">
                        <label className="form-label">Email Address *</label>
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className={`form-input ${errors.email ? 'input-error' : ''}`}
                            disabled={submitting}
                        />
                        {errors.email && (
                            <span className="error-message"><AlertCircle size={13} /> {errors.email}</span>
                        )}
                    </div>

                    <div className="form-group col-span-2">
                        <label className="form-label">New Password (leave empty to keep current password)</label>
                        <input
                            type="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            placeholder="Optional: enter new password"
                            className="form-input"
                            disabled={submitting}
                        />
                    </div>

                    <div className="modal-footer col-span-2">
                        <button
                            type="button"
                            onClick={onClose}
                            className="btn-secondary"
                            disabled={submitting}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="btn-primary"
                            disabled={submitting}
                        >
                            {submitting ? (
                                <>
                                    <span className="spinner-sm"></span>
                                    <span>Saving...</span>
                                </>
                            ) : (
                                <>
                                    <Save size={16} />
                                    <span>Save User Changes</span>
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
