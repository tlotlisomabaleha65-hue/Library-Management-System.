import React, { useState, useEffect } from 'react';
import { X, Save, AlertCircle } from 'lucide-react';

const COMMON_GENRES = [
    'Computer Science',
    'Programming',
    'Web Development',
    'Software Engineering',
    'Databases',
    'Information Technology',
    'Business & Management',
    'Cybersecurity',
    'Artificial Intelligence',
    'Mathematics'
];

export default function EditBookModal({ book, isOpen, onClose, onSave, submitting = false }) {
    const [formData, setFormData] = useState({
        title: '',
        author: '',
        genre: '',
        isbn: '',
        quantity: 0
    });
    const [errors, setErrors] = useState({});

    useEffect(() => {
        if (book) {
            setFormData({
                title: book.title || '',
                author: book.author || '',
                genre: book.genre || 'Computer Science',
                isbn: book.isbn || '',
                quantity: book.quantity !== undefined ? book.quantity : 0
            });
            setErrors({});
        }
    }, [book]);

    if (!isOpen || !book) return null;

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        if (errors[name]) {
            setErrors((prev) => ({ ...prev, [name]: null }));
        }
    };

    const validate = () => {
        const newErrors = {};
        if (!formData.title.trim()) newErrors.title = 'Title is required';
        if (!formData.author.trim()) newErrors.author = 'Author is required';
        if (!formData.genre.trim()) newErrors.genre = 'Genre is required';
        if (!formData.isbn.trim()) newErrors.isbn = 'ISBN is required';

        const qty = parseInt(formData.quantity, 10);
        if (isNaN(qty) || qty < 0) {
            newErrors.quantity = 'Quantity must be 0 or a positive number';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        await onSave(book.id, {
            title: formData.title.trim(),
            author: formData.author.trim(),
            genre: formData.genre.trim(),
            isbn: formData.isbn.trim(),
            quantity: parseInt(formData.quantity, 10)
        });
    };

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-container" onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                    <div>
                        <h3 className="modal-title">Update Book Details</h3>
                        <p className="modal-subtitle">ID #{book.id} • {book.isbn}</p>
                    </div>
                    <button className="modal-close-btn" onClick={onClose} aria-label="Close">
                        <X size={20} />
                    </button>
                </div>

                <form onSubmit={handleSubmit} noValidate className="modal-body form-grid">
                    <div className="form-group col-span-2">
                        <label className="form-label">Book Title *</label>
                        <input
                            type="text"
                            name="title"
                            value={formData.title}
                            onChange={handleChange}
                            className={`form-input ${errors.title ? 'input-error' : ''}`}
                            disabled={submitting}
                        />
                        {errors.title && (
                            <span className="error-message"><AlertCircle size={13} /> {errors.title}</span>
                        )}
                    </div>

                    <div className="form-group">
                        <label className="form-label">Author(s) *</label>
                        <input
                            type="text"
                            name="author"
                            value={formData.author}
                            onChange={handleChange}
                            className={`form-input ${errors.author ? 'input-error' : ''}`}
                            disabled={submitting}
                        />
                        {errors.author && (
                            <span className="error-message"><AlertCircle size={13} /> {errors.author}</span>
                        )}
                    </div>

                    <div className="form-group">
                        <label className="form-label">Genre *</label>
                        <select
                            name="genre"
                            value={formData.genre}
                            onChange={handleChange}
                            className="form-select"
                            disabled={submitting}
                        >
                            {COMMON_GENRES.map((g) => (
                                <option key={g} value={g}>{g}</option>
                            ))}
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label">ISBN *</label>
                        <input
                            type="text"
                            name="isbn"
                            value={formData.isbn}
                            onChange={handleChange}
                            className={`form-input ${errors.isbn ? 'input-error' : ''}`}
                            disabled={submitting}
                        />
                        {errors.isbn && (
                            <span className="error-message"><AlertCircle size={13} /> {errors.isbn}</span>
                        )}
                    </div>

                    <div className="form-group">
                        <label className="form-label">Quantity in Stock *</label>
                        <input
                            type="number"
                            name="quantity"
                            min="0"
                            value={formData.quantity}
                            onChange={handleChange}
                            className={`form-input ${errors.quantity ? 'input-error' : ''}`}
                            disabled={submitting}
                        />
                        {errors.quantity && (
                            <span className="error-message"><AlertCircle size={13} /> {errors.quantity}</span>
                        )}
                    </div>

                    <div className="modal-footer col-span-2">
                        <button
                            type="button"
                            onClick={onClose}
                            className="btn-secondary"
                            disabled={submitting}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="btn-primary"
                            disabled={submitting}
                        >
                            {submitting ? (
                                <>
                                    <span className="spinner-sm"></span>
                                    <span>Updating...</span>
                                </>
                            ) : (
                                <>
                                    <Save size={16} />
                                    <span>Save Changes</span>
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
