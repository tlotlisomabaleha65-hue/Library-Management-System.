import React from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from '../components/LoginForm';

export default function LoginPage() {
    const navigate = useNavigate();

    return (
        <div className="login-page-wrapper">
            <div className="login-box-container">
                <LoginForm onSuccess={() => navigate('/')} />
            </div>
        </div>
    );
}
