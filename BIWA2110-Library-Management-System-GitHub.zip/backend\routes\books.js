const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET /books - List all books (with optional search/genre filters)
router.get('/', async (req, res) => {
    try {
        const { search, genre } = req.query;
        let sql = 'SELECT * FROM books WHERE 1=1';
        const params = [];

        if (search) {
            sql += ' AND (title LIKE ? OR author LIKE ? OR isbn LIKE ?)';
            const term = `%${search}%`;
            params.push(term, term, term);
        }

        if (genre && genre !== 'All') {
            sql += ' AND genre = ?';
            params.push(genre);
        }

        sql += ' ORDER BY id DESC';

        const books = await db.query(sql, params);
        res.json({
            success: true,
            count: books.length,
            data: books
        });
    } catch (err) {
        console.error('Error fetching books:', err);
        res.status(500).json({ success: false, message: 'Server error while fetching books', error: err.message });
    }
});

// GET /books/:id - Get single book
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const books = await db.query('SELECT * FROM books WHERE id = ?', [id]);
        if (!books || books.length === 0) {
            return res.status(404).json({ success: false, message: 'Book not found' });
        }
        res.json({ success: true, data: books[0] });
    } catch (err) {
        console.error('Error fetching book:', err);
        res.status(500).json({ success: false, message: 'Server error while fetching book', error: err.message });
    }
});

// POST /books - Add new book
router.post('/', async (req, res) => {
    try {
        const { title, author, genre, isbn, quantity, userId } = req.body;

        // Validation
        if (!title || !title.trim()) {
            return res.status(400).json({ success: false, message: 'Title is required' });
        }
        if (!author || !author.trim()) {
            return res.status(400).json({ success: false, message: 'Author is required' });
        }
        if (!genre || !genre.trim()) {
            return res.status(400).json({ success: false, message: 'Genre is required' });
        }
        if (!isbn || !isbn.trim()) {
            return res.status(400).json({ success: false, message: 'ISBN is required' });
        }

        const initialQuantity = parseInt(quantity, 10);
        if (isNaN(initialQuantity) || initialQuantity < 0) {
            return res.status(400).json({ success: false, message: 'Quantity must be a non-negative number' });
        }

        // Check if ISBN already exists
        const existing = await db.query('SELECT id FROM books WHERE isbn = ?', [isbn.trim()]);
        if (existing && existing.length > 0) {
            return res.status(409).json({ success: false, message: 'A book with this ISBN already exists' });
        }

        const insertResult = await db.query(
            'INSERT INTO books (title, author, genre, isbn, quantity) VALUES (?, ?, ?, ?, ?)',
            [title.trim(), author.trim(), genre.trim(), isbn.trim(), initialQuantity]
        );

        const newBookId = insertResult.insertId;

        // If initial quantity is greater than 0, automatically log initial transaction
        if (initialQuantity > 0) {
            await db.query(
                'INSERT INTO transactions (book_id, user_id, transaction_type, quantity, notes) VALUES (?, ?, ?, ?, ?)',
                [newBookId, userId || null, 'ADD_STOCK', initialQuantity, 'Initial stock on registration']
            );
        }

        const [createdBook] = await db.query('SELECT * FROM books WHERE id = ?', [newBookId]);

        res.status(201).json({
            success: true,
            message: 'Book added successfully',
            data: createdBook
        });
    } catch (err) {
        console.error('Error adding book:', err);
        res.status(500).json({ success: false, message: 'Failed to add book', error: err.message });
    }
});

// PUT /books/:id - Update existing book details
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { title, author, genre, isbn, quantity } = req.body;

        const books = await db.query('SELECT * FROM books WHERE id = ?', [id]);
        if (!books || books.length === 0) {
            return res.status(404).json({ success: false, message: 'Book not found' });
        }

        // Validation
        if (!title || !title.trim()) {
            return res.status(400).json({ success: false, message: 'Title is required' });
        }
        if (!author || !author.trim()) {
            return res.status(400).json({ success: false, message: 'Author is required' });
        }
        if (!genre || !genre.trim()) {
            return res.status(400).json({ success: false, message: 'Genre is required' });
        }
        if (!isbn || !isbn.trim()) {
            return res.status(400).json({ success: false, message: 'ISBN is required' });
        }

        const qty = parseInt(quantity, 10);
        if (isNaN(qty) || qty < 0) {
            return res.status(400).json({ success: false, message: 'Quantity must be a non-negative number' });
        }

        // Check if ISBN is taken by another book
        const duplicate = await db.query('SELECT id FROM books WHERE isbn = ? AND id != ?', [isbn.trim(), id]);
        if (duplicate && duplicate.length > 0) {
            return res.status(409).json({ success: false, message: 'Another book already has this ISBN' });
        }

        await db.query(
            'UPDATE books SET title = ?, author = ?, genre = ?, isbn = ?, quantity = ? WHERE id = ?',
            [title.trim(), author.trim(), genre.trim(), isbn.trim(), qty, id]
        );

        const [updatedBook] = await db.query('SELECT * FROM books WHERE id = ?', [id]);

        res.json({
            success: true,
            message: 'Book updated successfully',
            data: updatedBook
        });
    } catch (err) {
        console.error('Error updating book:', err);
        res.status(500).json({ success: false, message: 'Failed to update book', error: err.message });
    }
});

// DELETE /books/:id - Delete book
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const books = await db.query('SELECT * FROM books WHERE id = ?', [id]);
        if (!books || books.length === 0) {
            return res.status(404).json({ success: false, message: 'Book not found' });
        }

        // Delete associated transactions first if CASCADE is not automatic
        await db.query('DELETE FROM transactions WHERE book_id = ?', [id]);
        await db.query('DELETE FROM books WHERE id = ?', [id]);

        res.json({
            success: true,
            message: `Book "${books[0].title}" deleted successfully`
        });
    } catch (err) {
        console.error('Error deleting book:', err);
        res.status(500).json({ success: false, message: 'Failed to delete book', error: err.message });
    }
});

module.exports = router;
