const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET /transactions - Transaction history log
router.get('/', async (req, res) => {
    try {
        const sql = `
            SELECT 
                t.id,
                t.book_id,
                t.user_id,
                t.transaction_type,
                t.quantity,
                t.notes,
                t.created_at,
                b.title AS book_title,
                b.isbn AS book_isbn,
                b.quantity AS current_stock,
                b.genre AS book_genre,
                u.name AS user_name,
                u.membership_id,
                u.role AS user_role
            FROM transactions t
            LEFT JOIN books b ON t.book_id = b.id
            LEFT JOIN users u ON t.user_id = u.id
            ORDER BY t.id DESC
        `;

        const transactions = await db.query(sql);
        res.json({
            success: true,
            count: transactions.length,
            data: transactions
        });
    } catch (err) {
        console.error('Error fetching transactions:', err);
        res.status(500).json({ success: false, message: 'Server error while fetching transactions', error: err.message });
    }
});

// GET /transactions/stats - Summary for Dashboard
router.get('/stats', async (req, res) => {
    try {
        const books = await db.query('SELECT id, quantity FROM books');
        const totalTitles = books.length;
        const totalCopiesInStock = books.reduce((sum, b) => sum + (parseInt(b.quantity, 10) || 0), 0);
        const lowStockCount = books.filter(b => (parseInt(b.quantity, 10) || 0) < 2).length;
        const outOfStockCount = books.filter(b => (parseInt(b.quantity, 10) || 0) === 0).length;

        const txRows = await db.query('SELECT transaction_type, quantity FROM transactions');
        let totalBorrowed = 0;
        let totalAdded = 0;
        txRows.forEach(tx => {
            const qty = parseInt(tx.quantity, 10) || 0;
            if (tx.transaction_type === 'BORROW_STOCK') {
                totalBorrowed += qty;
            } else if (tx.transaction_type === 'ADD_STOCK') {
                totalAdded += qty;
            }
        });

        const users = await db.query('SELECT COUNT(*) as count FROM users');
        const totalUsers = users[0]?.count || 0;

        res.json({
            success: true,
            data: {
                totalTitles,
                totalCopiesInStock,
                lowStockCount,
                outOfStockCount,
                totalTransactions: txRows.length,
                totalBorrowed,
                totalAdded,
                totalUsers
            }
        });
    } catch (err) {
        console.error('Error calculating stats:', err);
        res.status(500).json({ success: false, message: 'Failed to calculate stats', error: err.message });
    }
});

// POST /transactions - Record transaction (Add or Borrow Stock)
router.post('/', async (req, res) => {
    try {
        const { book_id, transaction_type, quantity, user_id, notes } = req.body;

        if (!book_id) {
            return res.status(400).json({ success: false, message: 'Book selection is required' });
        }

        const validTypes = ['ADD_STOCK', 'BORROW_STOCK'];
        if (!transaction_type || !validTypes.includes(transaction_type)) {
            return res.status(400).json({
                success: false,
                message: "Invalid transaction type. Must be 'ADD_STOCK' or 'BORROW_STOCK'"
            });
        }

        const qty = parseInt(quantity, 10);
        if (isNaN(qty) || qty <= 0) {
            return res.status(400).json({ success: false, message: 'Quantity must be a positive integer greater than zero' });
        }

        // Check if book exists and inspect current stock
        const bookResults = await db.query('SELECT * FROM books WHERE id = ?', [book_id]);
        if (!bookResults || bookResults.length === 0) {
            return res.status(404).json({ success: false, message: 'Selected book was not found' });
        }

        const book = bookResults[0];
        let newStock = book.quantity;

        if (transaction_type === 'BORROW_STOCK') {
            if (book.quantity < qty) {
                return res.status(400).json({
                    success: false,
                    message: `Cannot borrow ${qty} copy/copies. Only ${book.quantity} copy/copies currently in stock.`
                });
            }
            newStock = book.quantity - qty;
        } else if (transaction_type === 'ADD_STOCK') {
            newStock = book.quantity + qty;
        }

        // Update book stock
        await db.query('UPDATE books SET quantity = ? WHERE id = ?', [newStock, book_id]);

        // Insert transaction record
        const insertTx = await db.query(
            'INSERT INTO transactions (book_id, user_id, transaction_type, quantity, notes) VALUES (?, ?, ?, ?, ?)',
            [book_id, user_id || null, transaction_type, qty, notes || '']
        );

        const [createdTx] = await db.query(`
            SELECT 
                t.*,
                b.title AS book_title,
                b.isbn AS book_isbn,
                b.quantity AS current_stock,
                u.name AS user_name,
                u.membership_id
            FROM transactions t
            LEFT JOIN books b ON t.book_id = b.id
            LEFT JOIN users u ON t.user_id = u.id
            WHERE t.id = ?
        `, [insertTx.insertId]);

        res.status(201).json({
            success: true,
            message: transaction_type === 'ADD_STOCK'
                ? `Successfully added ${qty} copies to stock for "${book.title}". New stock: ${newStock}`
                : `Successfully borrowed ${qty} copies of "${book.title}". Remaining stock: ${newStock}`,
            data: createdTx,
            updatedStock: newStock
        });
    } catch (err) {
        console.error('Error processing transaction:', err);
        res.status(500).json({ success: false, message: 'Failed to process transaction', error: err.message });
    }
});

module.exports = router;
