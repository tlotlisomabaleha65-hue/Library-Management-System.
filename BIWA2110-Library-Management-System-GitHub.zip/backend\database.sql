-- ========================================================
-- BIWA2110 - Web Application Development Labtest
-- Database Schema for Library Management System (MySQL)
-- ========================================================

CREATE DATABASE IF NOT EXISTS library_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library_db;

-- 1. Users Table
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    membership_id VARCHAR(50) NOT NULL UNIQUE,
    role ENUM('Admin', 'Member', 'Librarian') NOT NULL DEFAULT 'Member',
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Books Table
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(150) NOT NULL,
    genre VARCHAR(80) NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    quantity INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 3. Transactions Table (Stock Availability & Borrowing History)
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    user_id INT NULL,
    transaction_type ENUM('ADD_STOCK', 'BORROW_STOCK') NOT NULL,
    quantity INT NOT NULL,
    notes VARCHAR(255) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ========================================================
-- Seed Data
-- ========================================================

-- Initial Users
INSERT INTO users (name, membership_id, role, email, password) VALUES
('System Administrator', 'ADM-001', 'Admin', 'admin@limkokwing.ac.ls', 'admin123'),
('John Doe', 'MEM-101', 'Member', 'john.doe@student.limkokwing.ac.ls', 'password123'),
('Jane Smith', 'MEM-102', 'Member', 'jane.smith@student.limkokwing.ac.ls', 'password123'),
('Thabo Mokoena', 'LIB-002', 'Librarian', 'thabo.mokoena@limkokwing.ac.ls', 'lib123');

-- Initial Books (with varied quantities to demonstrate low-stock highlighting < 2)
INSERT INTO books (title, author, genre, isbn, quantity) VALUES
('Clean Code: A Handbook of Agile Software Craftsmanship', 'Robert C. Martin', 'Software Engineering', '9780132350884', 5),
('JavaScript: The Good Parts', 'Douglas Crockford', 'Programming', '9780596517748', 1),
('Learning React: Modern Patterns for Developing React Apps', 'Alex Banks & Eve Porcello', 'Web Development', '9781492051725', 4),
('Node.js Design Patterns', 'Mario Casciaro', 'Backend Development', '9781839214110', 0),
('Database System Concepts', 'Abraham Silberschatz', 'Databases', '9780073523323', 8),
('Designing Data-Intensive Applications', 'Martin Kleppmann', 'Computer Science', '9781449373320', 2);

-- Initial Transactions
INSERT INTO transactions (book_id, user_id, transaction_type, quantity, notes) VALUES
(1, 1, 'ADD_STOCK', 5, 'Initial catalog shipment'),
(2, 2, 'ADD_STOCK', 3, 'Initial catalog batch'),
(2, 2, 'BORROW_STOCK', 2, 'Borrowed by John Doe for research assignment'),
(3, 1, 'ADD_STOCK', 4, 'Department acquisition'),
(4, 3, 'ADD_STOCK', 2, 'Semester stock delivery'),
(4, 3, 'BORROW_STOCK', 2, 'Borrowed by Jane Smith for final project'),
(5, 1, 'ADD_STOCK', 8, 'Curriculum textbooks'),
(6, 1, 'ADD_STOCK', 2, 'Library reference desk');
