import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import AddBookForm from '../components/AddBookForm';
import BookList from '../components/BookList';
import EditBookModal from '../components/EditBookModal';
import { useNotification } from '../context/NotificationContext';
import { useAuth } from '../context/AuthContext';

export default function BookManagement() {
    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [editingBook, setEditingBook] = useState(null);

    const { notifySuccess, notifyError, notifyInfo } = useNotification();
    const { user } = useAuth();

    const fetchBooks = async () => {
        setLoading(true);
        try {
            const res = await api.getBooks();
            if (res.success) {
                setBooks(res.data);
            }
        } catch (err) {
            notifyError('Failed to fetch books from server: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchBooks();
    }, []);

    // Add new book handler
    const handleAddBook = async (bookData) => {
        setSubmitting(true);
        try {
            const payload = {
                ...bookData,
                userId: user ? user.id : null
            };
            const res = await api.createBook(payload);
            if (res.success) {
                notifySuccess(`Book "${res.data.title}" added to inventory successfully!`);
                await fetchBooks();
                return true;
            }
        } catch (err) {
            notifyError('Could not add book: ' + err.message);
            return false;
        } finally {
            setSubmitting(false);
        }
    };

    // Update book handler
    const handleSaveBook = async (id, updatedData) => {
        setSubmitting(true);
        try {
            const res = await api.updateBook(id, updatedData);
            if (res.success) {
                notifySuccess(`Book "${res.data.title}" updated successfully!`);
                setEditingBook(null);
                await fetchBooks();
            }
        } catch (err) {
            notifyError('Failed to update book: ' + err.message);
        } finally {
            setSubmitting(false);
        }
    };

    // Delete book handler
    const handleDeleteBook = async (book) => {
        const confirmDelete = window.confirm(
            `Are you sure you want to permanently delete "${book.title}" (ISBN: ${book.isbn}) from the library?`
        );
        if (!confirmDelete) return;

        try {
            const res = await api.deleteBook(book.id);
            if (res.success) {
                notifySuccess(res.message || 'Book removed from catalog.');
                await fetchBooks();
            }
        } catch (err) {
            notifyError('Failed to delete book: ' + err.message);
        }
    };

    return (
        <div className="page-container">
            <div className="page-header">
                <div>
                    <h1 className="page-title">Book Management</h1>
                    <p className="page-subtitle">
                        Create, inspect, update, and manage the university book repository.
                    </p>
                </div>
            </div>

            {/* Form for adding new books */}
            <div className="mb-8">
                <AddBookForm onBookAdded={handleAddBook} submitting={submitting} />
            </div>

            {/* Editable list of books with Update and Delete buttons */}
            <div className="mb-8">
                <BookList
                    books={books}
                    loading={loading}
                    onEdit={(b) => setEditingBook(b)}
                    onDelete={handleDeleteBook}
                    showActions={true}
                    title="Library Books Catalog (Editable Records)"
                />
            </div>

            {/* Edit Modal Dialog */}
            <EditBookModal
                book={editingBook}
                isOpen={Boolean(editingBook)}
                onClose={() => setEditingBook(null)}
                onSave={handleSaveBook}
                submitting={submitting}
            />
        </div>
    );
}
