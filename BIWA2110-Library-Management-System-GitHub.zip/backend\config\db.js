const mysql = require('mysql2/promise');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
require('dotenv').config();

let dbMode = 'mysql';
let mysqlPool = null;
let sqliteDb = null;

const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'library_db',
    port: parseInt(process.env.DB_PORT, 10) || 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};

// Initialize SQLite database fallback with tables & initial seed data
function initSqlite() {
    return new Promise((resolve, reject) => {
        const dbPath = path.resolve(__dirname, '..', 'library.sqlite');
        sqliteDb = new sqlite3.Database(dbPath, async (err) => {
            if (err) {
                console.error('[DB] SQLite Initialization Error:', err.message);
                return reject(err);
            }
            console.log('[DB] Connected to embedded SQLite database:', dbPath);

            // Create tables if they do not exist
            sqliteDb.serialize(() => {
                sqliteDb.run(`
                    CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        membership_id TEXT NOT NULL UNIQUE,
                        role TEXT NOT NULL DEFAULT 'Member',
                        email TEXT NOT NULL UNIQUE,
                        password TEXT NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    );
                `);

                sqliteDb.run(`
                    CREATE TABLE IF NOT EXISTS books (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        author TEXT NOT NULL,
                        genre TEXT NOT NULL,
                        isbn TEXT NOT NULL UNIQUE,
                        quantity INTEGER NOT NULL DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    );
                `);

                sqliteDb.run(`
                    CREATE TABLE IF NOT EXISTS transactions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        book_id INTEGER NOT NULL,
                        user_id INTEGER,
                        transaction_type TEXT NOT NULL,
                        quantity INTEGER NOT NULL,
                        notes TEXT DEFAULT '',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
                    );
                `);

                // Check if seed data exists
                sqliteDb.get("SELECT COUNT(*) AS count FROM books", (err, row) => {
                    if (!err && row && row.count === 0) {
                        console.log('[DB] Seeding initial library data in SQLite...');
                        sqliteDb.serialize(() => {
                            const insertUser = sqliteDb.prepare("INSERT INTO users (name, membership_id, role, email, password) VALUES (?, ?, ?, ?, ?)");
                            insertUser.run('System Administrator', 'ADM-001', 'Admin', 'admin@limkokwing.ac.ls', 'admin123');
                            insertUser.run('John Doe', 'MEM-101', 'Member', 'john.doe@student.limkokwing.ac.ls', 'password123');
                            insertUser.run('Jane Smith', 'MEM-102', 'Member', 'jane.smith@student.limkokwing.ac.ls', 'password123');
                            insertUser.run('Thabo Mokoena', 'LIB-002', 'Librarian', 'thabo.mokoena@limkokwing.ac.ls', 'lib123');
                            insertUser.finalize();

                            const insertBook = sqliteDb.prepare("INSERT INTO books (title, author, genre, isbn, quantity) VALUES (?, ?, ?, ?, ?)");
                            insertBook.run('Clean Code: A Handbook of Agile Software Craftsmanship', 'Robert C. Martin', 'Software Engineering', '9780132350884', 5);
                            insertBook.run('JavaScript: The Good Parts', 'Douglas Crockford', 'Programming', '9780596517748', 1);
                            insertBook.run('Learning React: Modern Patterns for Developing React Apps', 'Alex Banks & Eve Porcello', 'Web Development', '9781492051725', 4);
                            insertBook.run('Node.js Design Patterns', 'Mario Casciaro', 'Backend Development', '9781839214110', 0);
                            insertBook.run('Database System Concepts', 'Abraham Silberschatz', 'Databases', '9780073523323', 8);
                            insertBook.run('Designing Data-Intensive Applications', 'Martin Kleppmann', 'Computer Science', '9781449373320', 2);
                            insertBook.finalize();

                            const insertTx = sqliteDb.prepare("INSERT INTO transactions (book_id, user_id, transaction_type, quantity, notes) VALUES (?, ?, ?, ?, ?)");
                            insertTx.run(1, 1, 'ADD_STOCK', 5, 'Initial catalog shipment');
                            insertTx.run(2, 2, 'ADD_STOCK', 3, 'Initial catalog batch');
                            insertTx.run(2, 2, 'BORROW_STOCK', 2, 'Borrowed by John Doe for research assignment');
                            insertTx.run(3, 1, 'ADD_STOCK', 4, 'Department acquisition');
                            insertTx.run(4, 3, 'ADD_STOCK', 2, 'Semester stock delivery');
                            insertTx.run(4, 3, 'BORROW_STOCK', 2, 'Borrowed by Jane Smith for final project');
                            insertTx.run(5, 1, 'ADD_STOCK', 8, 'Curriculum textbooks');
                            insertTx.run(6, 1, 'ADD_STOCK', 2, 'Library reference desk', (txErr) => {
                                console.log('[DB] Seeding completed.');
                                resolve();
                            });
                            insertTx.finalize();
                        });
                    } else {
                        resolve();
                    }
                });
            });
        });
    });
}

// Connect to Database
async function connectDB() {
    try {
        console.log(`[DB] Attempting connection to MySQL at ${dbConfig.host}:${dbConfig.port}...`);
        
        // Attempt MySQL connection with short timeout
        const testConn = await mysql.createConnection({
            host: dbConfig.host,
            user: dbConfig.user,
            password: dbConfig.password,
            port: dbConfig.port,
            connectTimeout: 2000
        });

        // Ensure database exists
        await testConn.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\`;`);
        await testConn.end();

        mysqlPool = mysql.createPool(dbConfig);
        await mysqlPool.query('SELECT 1');
        dbMode = 'mysql';
        console.log(`[DB] Successfully connected to MySQL database: ${dbConfig.database}`);

        // Run tables setup if not exist
        await mysqlPool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                membership_id VARCHAR(50) NOT NULL UNIQUE,
                role ENUM('Admin', 'Member', 'Librarian') NOT NULL DEFAULT 'Member',
                email VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await mysqlPool.query(`
            CREATE TABLE IF NOT EXISTS books (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(200) NOT NULL,
                author VARCHAR(150) NOT NULL,
                genre VARCHAR(80) NOT NULL,
                isbn VARCHAR(20) NOT NULL UNIQUE,
                quantity INT NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            );
        `);

        await mysqlPool.query(`
            CREATE TABLE IF NOT EXISTS transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                book_id INT NOT NULL,
                user_id INT NULL,
                transaction_type ENUM('ADD_STOCK', 'BORROW_STOCK') NOT NULL,
                quantity INT NOT NULL,
                notes VARCHAR(255) DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
            );
        `);

        // Check if books are seeded
        const [rows] = await mysqlPool.query('SELECT COUNT(*) as count FROM books');
        if (rows[0].count === 0) {
            console.log('[DB] Seeding default records into MySQL...');
            await mysqlPool.query(`
                INSERT INTO users (name, membership_id, role, email, password) VALUES
                ('System Administrator', 'ADM-001', 'Admin', 'admin@limkokwing.ac.ls', 'admin123'),
                ('John Doe', 'MEM-101', 'Member', 'john.doe@student.limkokwing.ac.ls', 'password123'),
                ('Jane Smith', 'MEM-102', 'Member', 'jane.smith@student.limkokwing.ac.ls', 'password123'),
                ('Thabo Mokoena', 'LIB-002', 'Librarian', 'thabo.mokoena@limkokwing.ac.ls', 'lib123');
            `);
            await mysqlPool.query(`
                INSERT INTO books (title, author, genre, isbn, quantity) VALUES
                ('Clean Code: A Handbook of Agile Software Craftsmanship', 'Robert C. Martin', 'Software Engineering', '9780132350884', 5),
                ('JavaScript: The Good Parts', 'Douglas Crockford', 'Programming', '9780596517748', 1),
                ('Learning React: Modern Patterns for Developing React Apps', 'Alex Banks & Eve Porcello', 'Web Development', '9781492051725', 4),
                ('Node.js Design Patterns', 'Mario Casciaro', 'Backend Development', '9781839214110', 0),
                ('Database System Concepts', 'Abraham Silberschatz', 'Databases', '9780073523323', 8),
                ('Designing Data-Intensive Applications', 'Martin Kleppmann', 'Computer Science', '9781449373320', 2);
            `);
            await mysqlPool.query(`
                INSERT INTO transactions (book_id, user_id, transaction_type, quantity, notes) VALUES
                (1, 1, 'ADD_STOCK', 5, 'Initial catalog shipment'),
                (2, 2, 'ADD_STOCK', 3, 'Initial catalog batch'),
                (2, 2, 'BORROW_STOCK', 2, 'Borrowed by John Doe for research assignment'),
                (3, 1, 'ADD_STOCK', 4, 'Department acquisition'),
                (4, 3, 'ADD_STOCK', 2, 'Semester stock delivery'),
                (4, 3, 'BORROW_STOCK', 2, 'Borrowed by Jane Smith for final project'),
                (5, 1, 'ADD_STOCK', 8, 'Curriculum textbooks'),
                (6, 1, 'ADD_STOCK', 2, 'Library reference desk');
            `);
            console.log('[DB] MySQL seeding finished.');
        }

    } catch (err) {
        console.warn('[DB] MySQL is not reachable or not started (' + err.message + ').');
        console.log('[DB] Gracefully activating SQLite embedded database layer for seamless evaluation...');
        dbMode = 'sqlite';
        await initSqlite();
    }
}

// Universal Query function
async function query(sqlText, params = []) {
    if (dbMode === 'mysql' && mysqlPool) {
        const [results] = await mysqlPool.query(sqlText, params);
        return results;
    } else {
        return new Promise((resolve, reject) => {
            const trimmed = sqlText.trim().toUpperCase();
            if (trimmed.startsWith('SELECT') || trimmed.startsWith('PRAGMA')) {
                sqliteDb.all(sqlText, params, (err, rows) => {
                    if (err) return reject(err);
                    resolve(rows);
                });
            } else {
                sqliteDb.run(sqlText, params, function (err) {
                    if (err) return reject(err);
                    resolve({
                        insertId: this.lastID,
                        affectedRows: this.changes
                    });
                });
            }
        });
    }
}

function getDatabaseStatus() {
    return {
        mode: dbMode,
        databaseName: dbMode === 'mysql' ? dbConfig.database : 'library.sqlite',
        host: dbMode === 'mysql' ? dbConfig.host : 'localhost (embedded)'
    };
}

module.exports = {
    connectDB,
    query,
    getDatabaseStatus
};
