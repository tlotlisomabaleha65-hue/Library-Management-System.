import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookPlus, ArrowLeftRight, Users, Sparkles, AlertTriangle } from 'lucide-react';
import { api } from '../services/api';
import DashboardStats from '../components/DashboardStats';
import BookList from '../components/BookList';
import { useNotification } from '../context/NotificationContext';

export default function Dashboard() {
    const [stats, setStats] = useState(null);
    const [books, setBooks] = useState([]);
    const [recentTx, setRecentTx] = useState([]);
    const [loading, setLoading] = useState(true);
    const { notifyError } = useNotification();

    const loadData = async () => {
        setLoading(true);
        try {
            const [statsRes, booksRes, txRes] = await Promise.all([
                api.getStats(),
                api.getBooks(),
                api.getTransactions()
            ]);

            if (statsRes.success) setStats(statsRes.data);
            if (booksRes.success) setBooks(booksRes.data);
            if (txRes.success) setRecentTx(txRes.data.slice(0, 5));
        } catch (err) {
            notifyError('Could not connect to backend API: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    // Filter books with low stock (< 2 copies)
    const lowStockBooks = books.filter((b) => (parseInt(b.quantity, 10) || 0) < 2);

    return (
        <div className="page-container">
            {/* Hero / Header Section */}
            <div className="dashboard-hero">
                <div className="hero-content">
                    <span className="hero-pill">
                        <Sparkles size={14} /> Faculty of ICT • Limkokwing University
                    </span>
                    <h1 className="hero-title">Library Management & Circulation System</h1>
                    <p className="hero-desc">
                        Real-time tracking of book availability, member circulation, and stock transactions for course BIWA2110.
                    </p>
                </div>

                <div className="hero-actions">
                    <Link to="/books" className="btn-hero-primary">
                        <BookPlus size={18} />
                        <span>Manage Books</span>
                    </Link>
                    <Link to="/transactions" className="btn-hero-secondary">
                        <ArrowLeftRight size={18} />
                        <span>Record Stock / Loan</span>
                    </Link>
                </div>
            </div>

            {/* KPI Metrics */}
            <DashboardStats stats={stats} loading={loading} />

            {/* Low Stock Alert Banner if any books < 2 */}
            {lowStockBooks.length > 0 && !loading && (
                <div className="low-stock-alert-banner">
                    <div className="alert-banner-header">
                        <AlertTriangle size={20} className="alert-banner-icon" />
                        <div>
                            <h4>Attention: {lowStockBooks.length} Title(s) Have Low or Zero Stock!</h4>
                            <p>
                                The following books have fewer than 2 copies available in inventory. Restock recommended:
                            </p>
                        </div>
                    </div>
                    <div className="alert-tags-container">
                        {lowStockBooks.map((b) => (
                            <span key={b.id} className="low-stock-chip">
                                <strong>{b.title}</strong> — {b.quantity === 0 ? 'Out of Stock (0)' : 'Only 1 copy left'}
                            </span>
                        ))}
                    </div>
                </div>
            )}

            {/* Main Content Layout */}
            <div className="dashboard-content-grid">
                {/* Book Availability Table */}
                <div className="dashboard-main-col">
                    <BookList
                        books={books}
                        loading={loading}
                        showActions={false}
                        title="Live Inventory & Availability"
                    />
                </div>

                {/* Sidebar: Recent Activity & Quick Navigation */}
                <div className="dashboard-side-col">
                    <div className="card-container side-card">
                        <div className="card-header-flex">
                            <h3 className="section-title">Recent Transactions</h3>
                            <Link to="/transactions" className="link-view-all">
                                View all <ArrowRight size={14} />
                            </Link>
                        </div>

                        {recentTx.length === 0 ? (
                            <p className="text-muted p-4">No recent stock activity logged.</p>
                        ) : (
                            <div className="recent-tx-list">
                                {recentTx.map((tx) => {
                                    const isAdd = tx.transaction_type === 'ADD_STOCK';
                                    return (
                                        <div key={tx.id} className="recent-tx-item">
                                            <div className={`tx-dot ${isAdd ? 'dot-add' : 'dot-borrow'}`}></div>
                                            <div className="tx-details">
                                                <div className="tx-book-title">{tx.book_title}</div>
                                                <div className="tx-meta">
                                                    <span className={isAdd ? 'text-success' : 'text-primary'}>
                                                        {isAdd ? `+${tx.quantity} Restocked` : `-${tx.quantity} Borrowed`}
                                                    </span>
                                                    <span>•</span>
                                                    <span>{tx.user_name || 'Staff'}</span>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>

                    {/* System Summary Card */}
                    <div className="card-container side-card quick-links-card">
                        <h3 className="section-title">Labtest Navigation</h3>
                        <div className="quick-links-list">
                            <Link to="/books" className="quick-link-item">
                                <BookPlus size={18} />
                                <div>
                                    <strong>Book Management</strong>
                                    <p>Add, update, and remove catalog entries</p>
                                </div>
                            </Link>
                            <Link to="/transactions" className="quick-link-item">
                                <ArrowLeftRight size={18} />
                                <div>
                                    <strong>Availability Management</strong>
                                    <p>Add new stock and deduct borrowed copies</p>
                                </div>
                            </Link>
                            <Link to="/users" className="quick-link-item">
                                <Users size={18} />
                                <div>
                                    <strong>User Management</strong>
                                    <p>Login authentication and user CRUD operations</p>
                                </div>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
