import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import LoginForm from '../components/LoginForm';
import UserForm from '../components/UserForm';
import UserList from '../components/UserList';
import EditUserModal from '../components/EditUserModal';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import { ShieldCheck, UserPlus, LogIn, Sparkles } from 'lucide-react';

export default function UserManagement() {
    const { user } = useAuth();
    const { notifySuccess, notifyError } = useNotification();

    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [editingUser, setEditingUser] = useState(null);

    const fetchUsers = async () => {
        setLoading(true);
        try {
            const res = await api.getUsers();
            if (res.success) {
                setUsers(res.data);
            }
        } catch (err) {
            notifyError('Failed to fetch users: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    // Create user handler
    const handleAddUser = async (userData) => {
        setSubmitting(true);
        try {
            const res = await api.createUser(userData);
            if (res.success) {
                notifySuccess(`Account for "${res.data.name}" (${res.data.membership_id}) created!`);
                await fetchUsers();
                return true;
            }
        } catch (err) {
            notifyError('Could not register user: ' + err.message);
            return false;
        } finally {
            setSubmitting(false);
        }
    };

    // Update user handler
    const handleSaveUser = async (id, updatedData) => {
        setSubmitting(true);
        try {
            const res = await api.updateUser(id, updatedData);
            if (res.success) {
                notifySuccess(`User "${res.data.name}" updated successfully!`);
                setEditingUser(null);
                await fetchUsers();
            }
        } catch (err) {
            notifyError('Could not update user: ' + err.message);
        } finally {
            setSubmitting(false);
        }
    };

    // Delete user handler
    const handleDeleteUser = async (targetUser) => {
        if (user && String(user.id) === String(targetUser.id)) {
            notifyError('You cannot delete your own logged-in account.');
            return;
        }

        const confirmDelete = window.confirm(
            `Are you sure you want to remove user "${targetUser.name}" (${targetUser.membership_id})?`
        );
        if (!confirmDelete) return;

        try {
            const res = await api.deleteUser(targetUser.id);
            if (res.success) {
                notifySuccess(res.message);
                await fetchUsers();
            }
        } catch (err) {
            notifyError('Failed to delete user: ' + err.message);
        }
    };

    return (
        <div className="page-container">
            <div className="page-header">
                <div>
                    <h1 className="page-title">User Management & Authentication</h1>
                    <p className="page-subtitle">
                        Student and faculty member accounts, authentication, and role administration.
                    </p>
                </div>
            </div>

            {/* Split Grid: Left = Login Form, Right = Add New User Form */}
            <div className="user-management-grid mb-8">
                {/* 1. Login form for users */}
                <div>
                    <LoginForm />
                </div>

                {/* 2. Add new users form */}
                <div>
                    <UserForm onUserAdded={handleAddUser} submitting={submitting} />
                </div>
            </div>

            {/* 3. Admin view with table to add/update/delete users */}
            <div className="mb-8">
                <UserList
                    users={users}
                    loading={loading}
                    onEditUser={(u) => setEditingUser(u)}
                    onDeleteUser={handleDeleteUser}
                    currentUserId={user?.id}
                />
            </div>

            {/* Edit User Modal */}
            <EditUserModal
                user={editingUser}
                isOpen={Boolean(editingUser)}
                onClose={() => setEditingUser(null)}
                onSave={handleSaveUser}
                submitting={submitting}
            />
        </div>
    );
}
