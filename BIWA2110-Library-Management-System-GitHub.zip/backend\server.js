const express = require('express');
const cors = require('cors');
require('dotenv').config();

const db = require('./config/db');
const booksRouter = require('./routes/books');
const transactionsRouter = require('./routes/transactions');
const usersRouter = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Request logger for debugging and audit
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
    next();
});

// Mount Routes (supporting both /api/* and root /* patterns to satisfy brief directly)
app.use('/api/books', booksRouter);
app.use('/books', booksRouter);

app.use('/api/transactions', transactionsRouter);
app.use('/transactions', transactionsRouter);

app.use('/api/users', usersRouter);
app.use('/users', usersRouter);

// System Health & Database status endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'online',
        timestamp: new Date().toISOString(),
        system: 'BIWA2110 Library Management System API',
        database: db.getDatabaseStatus()
    });
});

app.get('/', (req, res) => {
    res.send(`
        <html>
            <head><title>BIWA2110 Library API</title></head>
            <body style="font-family: Arial, sans-serif; padding: 40px; background: #f8fafc; color: #1e293b;">
                <h2>BIWA2110 - Library Management System API</h2>
                <p>Status: <span style="color: green; font-weight: bold;">Running</span></p>
                <ul>
                    <li><a href="/api/books">/api/books</a> (Books CRUD)</li>
                    <li><a href="/api/transactions">/api/transactions</a> (Stock & Borrowing History)</li>
                    <li><a href="/api/transactions/stats">/api/transactions/stats</a> (Dashboard Statistics)</li>
                    <li><a href="/api/users">/api/users</a> (User Management)</li>
                    <li><a href="/api/health">/api/health</a> (DB Engine Status)</li>
                </ul>
            </body>
        </html>
    `);
});

// 404 Handler
app.use((req, res) => {
    res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

// Global Error Handler
app.use((err, req, res, next) => {
    console.error('Unhandled server error:', err);
    res.status(500).json({ success: false, message: 'Internal server error', error: err.message });
});

// Connect to DB and Start Server
async function startServer() {
    await db.connectDB();
    app.listen(PORT, () => {
        console.log(`=======================================================`);
        console.log(` BIWA2110 Express Server running on http://localhost:${PORT}`);
        console.log(` Database: ${JSON.stringify(db.getDatabaseStatus())}`);
        console.log(`=======================================================`);
    });
}

startServer();
