const express = require('express');
const router = express.Router();
const db = require('../config/db');

// POST /users/login - User Authentication
router.post('/login', async (req, res) => {
    try {
        const { identifier, password } = req.body;

        if (!identifier || !identifier.trim() || !password) {
            return res.status(400).json({
                success: false,
                message: 'Please provide both Email/Membership ID and Password'
            });
        }

        const cleanIdentifier = identifier.trim();
        const users = await db.query(
            'SELECT id, name, membership_id, role, email, password FROM users WHERE email = ? OR membership_id = ?',
            [cleanIdentifier, cleanIdentifier]
        );

        if (!users || users.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email/membership ID or password'
            });
        }

        const user = users[0];

        // Direct password match (for labtest demonstration)
        if (user.password !== password) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email/membership ID or password'
            });
        }

        const safeUser = {
            id: user.id,
            name: user.name,
            membership_id: user.membership_id,
            role: user.role,
            email: user.email
        };

        res.json({
            success: true,
            message: `Welcome back, ${safeUser.name}!`,
            user: safeUser
        });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ success: false, message: 'Server error during login', error: err.message });
    }
});

// GET /users - List all users
router.get('/', async (req, res) => {
    try {
        const users = await db.query(
            'SELECT id, name, membership_id, role, email, created_at FROM users ORDER BY id ASC'
        );
        res.json({
            success: true,
            count: users.length,
            data: users
        });
    } catch (err) {
        console.error('Error fetching users:', err);
        res.status(500).json({ success: false, message: 'Server error while fetching users', error: err.message });
    }
});

// GET /users/:id - Get single user
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const users = await db.query(
            'SELECT id, name, membership_id, role, email, created_at FROM users WHERE id = ?',
            [id]
        );
        if (!users || users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }
        res.json({ success: true, data: users[0] });
    } catch (err) {
        console.error('Error fetching user:', err);
        res.status(500).json({ success: false, message: 'Server error while fetching user', error: err.message });
    }
});

// POST /users - Add new user
router.post('/', async (req, res) => {
    try {
        const { name, membership_id, role, email, password } = req.body;

        if (!name || !name.trim()) {
            return res.status(400).json({ success: false, message: 'User name is required' });
        }
        if (!membership_id || !membership_id.trim()) {
            return res.status(400).json({ success: false, message: 'Membership ID is required' });
        }
        if (!email || !email.trim()) {
            return res.status(400).json({ success: false, message: 'Email address is required' });
        }

        const validRoles = ['Admin', 'Member', 'Librarian'];
        const assignedRole = validRoles.includes(role) ? role : 'Member';
        const userPassword = password && password.trim() ? password.trim() : 'password123';

        // Check uniqueness of membership_id and email
        const existingMember = await db.query('SELECT id FROM users WHERE membership_id = ?', [membership_id.trim()]);
        if (existingMember && existingMember.length > 0) {
            return res.status(409).json({ success: false, message: 'This Membership ID is already registered' });
        }

        const existingEmail = await db.query('SELECT id FROM users WHERE email = ?', [email.trim().toLowerCase()]);
        if (existingEmail && existingEmail.length > 0) {
            return res.status(409).json({ success: false, message: 'This email is already in use' });
        }

        const insertResult = await db.query(
            'INSERT INTO users (name, membership_id, role, email, password) VALUES (?, ?, ?, ?, ?)',
            [name.trim(), membership_id.trim(), assignedRole, email.trim().toLowerCase(), userPassword]
        );

        const newId = insertResult.insertId;
        const [newUser] = await db.query(
            'SELECT id, name, membership_id, role, email, created_at FROM users WHERE id = ?',
            [newId]
        );

        res.status(201).json({
            success: true,
            message: `User "${newUser.name}" registered successfully`,
            data: newUser
        });
    } catch (err) {
        console.error('Error creating user:', err);
        res.status(500).json({ success: false, message: 'Failed to create user', error: err.message });
    }
});

// PUT /users/:id - Update user details
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { name, membership_id, role, email, password } = req.body;

        const users = await db.query('SELECT * FROM users WHERE id = ?', [id]);
        if (!users || users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        if (!name || !name.trim()) {
            return res.status(400).json({ success: false, message: 'User name is required' });
        }
        if (!membership_id || !membership_id.trim()) {
            return res.status(400).json({ success: false, message: 'Membership ID is required' });
        }
        if (!email || !email.trim()) {
            return res.status(400).json({ success: false, message: 'Email address is required' });
        }

        // Uniqueness check
        const dupMember = await db.query('SELECT id FROM users WHERE membership_id = ? AND id != ?', [membership_id.trim(), id]);
        if (dupMember && dupMember.length > 0) {
            return res.status(409).json({ success: false, message: 'This Membership ID is taken by another user' });
        }

        const dupEmail = await db.query('SELECT id FROM users WHERE email = ? AND id != ?', [email.trim().toLowerCase(), id]);
        if (dupEmail && dupEmail.length > 0) {
            return res.status(409).json({ success: false, message: 'This email is taken by another user' });
        }

        const validRoles = ['Admin', 'Member', 'Librarian'];
        const assignedRole = validRoles.includes(role) ? role : users[0].role;
        const updatedPassword = password && password.trim() ? password.trim() : users[0].password;

        await db.query(
            'UPDATE users SET name = ?, membership_id = ?, role = ?, email = ?, password = ? WHERE id = ?',
            [name.trim(), membership_id.trim(), assignedRole, email.trim().toLowerCase(), updatedPassword, id]
        );

        const [updatedUser] = await db.query(
            'SELECT id, name, membership_id, role, email, created_at FROM users WHERE id = ?',
            [id]
        );

        res.json({
            success: true,
            message: `User "${updatedUser.name}" updated successfully`,
            data: updatedUser
        });
    } catch (err) {
        console.error('Error updating user:', err);
        res.status(500).json({ success: false, message: 'Failed to update user', error: err.message });
    }
});

// DELETE /users/:id - Delete user
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const users = await db.query('SELECT * FROM users WHERE id = ?', [id]);
        if (!users || users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        await db.query('DELETE FROM users WHERE id = ?', [id]);

        res.json({
            success: true,
            message: `User "${users[0].name}" (${users[0].membership_id}) deleted successfully`
        });
    } catch (err) {
        console.error('Error deleting user:', err);
        res.status(500).json({ success: false, message: 'Failed to delete user', error: err.message });
    }
});

module.exports = router;
