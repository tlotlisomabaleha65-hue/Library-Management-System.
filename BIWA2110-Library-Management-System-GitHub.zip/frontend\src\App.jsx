import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import BookManagement from './pages/BookManagement';
import Transactions from './pages/Transactions';
import UserManagement from './pages/UserManagement';
import LoginPage from './pages/LoginPage';

export default function App() {
    return (
        <div className="app-layout">
            <Navbar />
            <main className="main-content">
                <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/books" element={<BookManagement />} />
                    <Route path="/transactions" element={<Transactions />} />
                    <Route path="/users" element={<UserManagement />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </main>
            <footer className="app-footer">
                <div className="footer-container">
                    <p>
                        <strong>Web Application Development - BIWA2110 Labtest (20%)</strong>
                    </p>
                    <p className="footer-subtext">
                        Limkokwing University of Creative Technology • Faculty of Information Communication Technology
                    </p>
                    <p className="footer-tech">
                        Built with React Hooks &amp; Router, Express.js REST API, and Relational Database Integration.
                    </p>
                </div>
            </footer>
        </div>
    );
}
